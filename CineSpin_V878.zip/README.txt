CINÉSPIN V8.7.8 — AJUSTEMENTS HERO / GLASSMORPHISME

Modifications à partir de V8.7.7 : +65 % d’espace entre sur-titre et titre;
-50 % entre titre et description; -30 % d’interlettrage pour « MOINS DE RECHERCHE » seulement.
Sur-titre en pilule dark glass, contour blanc, fond plus fin, aucune icône.
Textes, catalogue, profils, avatars GIF et galerie infinie inchangés.

DÉPLOIEMENT : remplacer les fichiers sur le site Netlify EXISTANT, sans changer de domaine.

--- NOTES DE LA VERSION PRÉCÉDENTE ---
CINÉSPIN V8.7.7 — AVATARS GIF CINÉMA

Modifications par rapport à V8.7.6 :
- Conservation des cinq avatars illustrés et du profil existant.
- Ajout de sept GIF provenant de Wikimedia Commons : clap, bobine, popcorn, décompte, zootrope, projecteur, caméra.
- Séparation dans le choix d’avatar : « Les originaux » et « GIF cinéma ».
- Sauvegarde du choix dans le profil local, exactement comme les avatars classiques.
- Les GIF externes requièrent Internet ; en cas d’échec, l’interface affiche automatiquement un avatar classique de secours.
- Respect de la préférence système de réduction du mouvement : avatar classique statique en remplacement.
- Sources, auteurs et licences consultables dans le sélecteur.
- Nouvelle version du cache pour forcer le chargement du code récent sur Netlify.

ATTENTION : les GIF sont chargés depuis les serveurs Wikimedia, ils ne sont PAS inclus physiquement dans le ZIP. Si leur lien change, l’avatar de secours s’affiche.

Autres fonctions et textes : inchangés.

Sources :
https://commons.wikimedia.org/wiki/File:Claqueta2.gif (CC0)
https://commons.wikimedia.org/wiki/File:Bobine.gif (CC0)
https://commons.wikimedia.org/wiki/File:Slowmotion_popcorn.gif (CC BY-SA 3.0)
https://commons.wikimedia.org/wiki/File:10_seconds_countdown.gif (domaine public)
https://commons.wikimedia.org/wiki/File:Animation_de_Daisy-Muybridge-_par_un_Zootrope.gif (CC BY-SA 4.0)
https://commons.wikimedia.org/wiki/File:Mécanisme_du_cinématographe_des_frères_Lumière.gif (CC BY-SA 4.0)
https://commons.wikimedia.org/wiki/File:Moviecam_schematic_animation.gif (licences sur la page)
CINÉSPIN V8.7.6 — HERO : « PLUS DE PLOT TWISTS »

Changements uniquement dans le héros, depuis V8.7.5 :
- Remplacer « PLUS D’ÉCOUTE » par « PLUS DE PLOT TWISTS ».
- Inverser exactement les marges verticales entre : sur-titre et titre, puis titre et paragraphe.
  > Desktop : sur-titre → titre : clamp(20px,2.4vw,32px) ; titre → paragraphe : clamp(19px,2.4vw,28px).
  > Mobile <=720px : sur-titre → titre : 26px ; titre → paragraphe : 21px.
  > Mobile <=400px : sur-titre → titre : 23px ; titre → paragraphe : 21px.
- La taille synchronisée du titre sur mobile (95 % de la largeur utile), son contour blanc et l'interligne interne restent inchangés.
- Le versionnement du cache CSS et service worker est mis à jour pour éviter l'ancienne version.
- Aucune modification du catalogue, des profils, de la roulette ou de la galerie infinie.

--- HISTORIQUE ---
CINÉSPIN V8.7.5 — LARGEUR DU TITRE ET FINESSE DU CONTOUR

Deux ajustements uniquement depuis V8.7.4 :
- Sur mobile, « MOINS DE RECHERCHE, » occupe environ 95 % de la largeur utile (et reste sur une ligne). La ligne du bas conserve exactement la même taille de texte.
- « PLUS D’ÉCOUTE » conserve le contour blanc CSS centré (-webkit-text-stroke n'est pas un contour extérieur), affiné de 20 % supplémentaire : 1,4→1,12 px bureau ; 1,12→0,896 px mobile ; 1,05→0,84 px sur très petits écrans.

Aucune modification aux textes, aux affiches, à la galerie infinie, au bouton œil, aux profils ou aux roulettes.
Pour le déploiement, remplacer les fichiers du site Netlify existant afin de conserver le même domaine et les données locales.

--- HISTORIQUE ---
CINÉSPIN V8.7.4 — TITRE RESPONSIVE (CORRECTIF CIBLÉ)

Modifications par rapport à V8.7.3 :
- « MOINS DE RECHERCHE, » reste sur une seule ligne et occupe environ 85 % de la largeur intérieure disponible sur mobile, y compris les petits iPhone.
- « PLUS D’ÉCOUTE » utilise strictement la même taille de caractères que la première ligne.
- Contour blanc « PLUS D’ÉCOUTE » réduit de 30 % (2 px → 1,4 px sur ordinateur, 1,6 px → 1,12 px ou 1,5 px → 1,05 px sur mobile).
- Tous les textes, la galerie infinie, l’œil, les profils, le catalogue, les boutons et la logique du jeu restent inchangés.

Netlify : republier sur le site existant pour garder la même adresse et les données enregistrées dans le navigateur.

--- HISTORIQUE ---
CINÉSPIN V8.7.3 — POLISSAGE VISUEL DU HÉROS

Basé sur CineSpin V8.7.2. Quatre changements ciblés UNIQUEMENT :
1. Contenu du héros remonté pour réduire l’espace vide supérieur.
2. Sur-titre actuel inchangé, présenté dans une étiquette mauve avec icône SVG originale de machine à sous de casino.
3. Titre actuel inchangé, taille augmentée de 25 % aux différents points de rupture, interligne rapproché afin de ne pas accroître l’espace entre les lignes.
4. Dégradé du bouton principal corrigé, avec bordure et ombre simplifiées.

Le voile sur les affiches (point 5) n’a PAS été modifié.
Les textes, scripts, profils, films, séries, jeu et galerie infinie sont inchangés.

Déploiement : déposer les fichiers ZIP sur le même site Netlify pour conserver son domaine et les données du navigateur.

--- HISTORIQUE CONSERVÉ ---
CINÉSPIN V8.7.1 — CORRECTIF ALIGNEMENT VIGNETTES

Correction ciblée : en mode héros visible, les affiches utilisent maintenant toutes
le même centrage que le mode galerie. Le problème de chevauchement des affiches
est corrigé. Aucun autre changement au catalogue, aux profils ou à la navigation.

CINÉSPIN V8.7 — GALERIE INFINIE & AFFICHES RÉELLES

Basé directement sur la V8.6.

Nouveau dans le héros :
- Scroll libre et cyclique dans les quatre directions, sans changer le zoom.
- La mosaïque se prolonge avec les mêmes films au-delà de chaque bord.
- Les plus populaires démarrent au centre.
- Les affiches présentes sont celles des sources vérifiées (IMDb / TMDB).
- Les fiches sans URL de vraie affiche ne sont pas dessinées dans le mur;
  elles restent consultables dans le catalogue.
- Les affiches introuvables (HTTP 404, etc.) sont écartées du mur plutôt
  que de devenir des vignettes fictives.
- L'œil réaffiche le texte et remet le mur à sa position centrale.
- Déplacement au doigt ou en cliquer-glisser; un simple clic ouvre la fiche.
- Chargement des seules vignettes visibles pour conserver la fluidité sur iPhone.

Déploiement : décompresser le ZIP et déployer le dossier sur Netlify,
conserver le même domaine pour réutiliser les profils du navigateur.

Limites de données : une source externe ne garantit pas que chaque film
possède une affiche officielle récupérable. Les titres sans image
restent dans le catalogue avec une indication explicite.


V8.7.2 : Bouton œil du héros descendu de 16 px sur mobile et ordinateur pour davantage d’espace sous la navigation. Aucune autre fonctionnalité modifiée.
