/* Offline shell cache; remote rating sources are always network-only. */
const CACHE='cinespin-shell-v8-7-8-hero-spacing-glass';
const FILES=['/','/index.html','/styles.css','/app.js','/manifest.webmanifest','/assets/cinespin-logo-approved.png','/assets/avatar-gobelin-v8.png','/assets/avatar-poule-v8.png','/assets/avatar-magicien-v8.png','/assets/avatar-royaux-v8.png','/assets/avatar-ver-v8.png','/assets/dragon-original.png','/assets/mascotte-popcorn.png','/assets/mascotte-television.png','/assets/mascotte-sieste.png','/assets/icon-192.png','/assets/poster-fallback.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{let r=e.request;if(r.method!=='GET'||new URL(r.url).origin!==location.origin)return;e.respondWith(fetch(r).catch(()=>caches.match(r)).then(x=>x||new Response('Hors ligne',{status:503})))});
