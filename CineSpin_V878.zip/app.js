/* CinéSpin V8.7.7 — application personnelle, sans backend. Tous les scores proviennent de sources indiquées. */
'use strict';
const $=id=>document.getElementById(id);
const PALETTE={Action:'#ff4f48',Adventure:'#ff8e42',Animation:'#b9a5ff',Biography:'#ecc747',Comedy:'#ffd34f',Crime:'#3157ff',Drama:'#e4b2e8',Family:'#6ddfc4',Fantasy:'#a88cf4',History:'#efa357',Horror:'#e94b64',Music:'#f17fb7',Mystery:'#907aff',Romance:'#ff9fcb','Science Fiction':'#284bd8',Sport:'#f2be37',Thriller:'#5675f8',War:'#ed7848',Western:'#ffc55f',Musical:'#40bfad'};
const NAMES={Action:'Action',Adventure:'Aventure',Animation:'Animation',Biography:'Biographie',Comedy:'Comédie',Crime:'Policier',Drama:'Drame',Family:'Famille',Fantasy:'Fantastique',History:'Historique',Horror:'Horreur',Music:'Musique',Mystery:'Mystère',Romance:'Romance','Science Fiction':'Science-fiction',Sport:'Sport',Thriller:'Suspense',War:'Guerre',Western:'Western',Musical:'Comédie musicale'};
const ICONS={Action:'⚡',Adventure:'🗺️',Animation:'🎨',Biography:'📜',Comedy:'🎭',Crime:'🕵️',Drama:'🎬',Family:'🎈',Fantasy:'🔮',History:'🏛️',Horror:'🦇',Music:'🎸',Mystery:'🔍',Romance:'💘','Science Fiction':'🛸',Sport:'🏆',Thriller:'🗝️',War:'🛡️',Western:'🤠',Musical:'🎤'};
const GENRE_MAP={Action:['Action','Adventure','War','Western','Sport'],Comedy:['Comedy','Music','Musical'],Drama:['Drama'],Thriller:['Thriller','Mystery','Crime'],Horror:['Horror'],'Science Fiction':['Science Fiction'],Fantasy:['Fantasy'],Romance:['Romance'],Animation:['Animation','Family'],Biography:['Biography','History']};
const GENRE_COLORS={Action:'#FF4F48',Comedy:'#FFD34F',Drama:'#B9A5FF',Thriller:'#3157FF',Horror:'#FF8E42','Science Fiction':'#6DDFC4',Fantasy:'#B49CFF',Romance:'#FF9FCB',Animation:'#FFCD49',Biography:'#90E5CC'};
const CATS=Object.keys(GENRE_MAP);
function categoriesFor(m){return CATS.filter(k=>m.genres?.some(g=>GENRE_MAP[k].includes(g)))}
function prizeImage(g){return 'assets/genres/'+g.toLowerCase().replaceAll(' ','-')+'.svg'}
const WIT=['Pas ce soir, Satan.','Celui-là attendra ma prochaine réincarnation.','Même mon ex avait de meilleures idées.','Le popcorn mérite mieux.','Suivant. Le destin vient de perdre son permis.','Ce film ne passera pas le générique.'];
const SOURCE_MIRROR='https://quantavil.github.io/imdb-dataset/titles.json.gz';
const SOURCE_MIRROR_JSON='https://quantavil.github.io/imdb-dataset/titles.json';
const HF='https://datasets-server.huggingface.co/filter';
const HF_DATASET='HenryWaltson/TMDB-IMDB-Movies-Dataset';
const PROFILES_KEY='cinespin_v5_profiles',ACTIVE_KEY='cinespin_v5_active',COUNTRY_KEY='cinespin_v5_countries';

// V8.7.7 — GIFs de cinéma en complément des portraits approuvés.
// Les GIFs proviennent de Wikimedia Commons ; leurs licences figurent dans le sélecteur.
// Les URLs sont des redirections Wikimedia officielles : aucune image externe n'est sauvegardée localement.
const AVATARS=[
  {id:'gobelin',label:'Gobelin',image:'assets/avatar-gobelin-v8.png',bg:'#3C254E',zoom:'100%',top:'0%'},
  {id:'poule',label:'Poule',image:'assets/avatar-poule-v8.png',bg:'#172E65',zoom:'100%',top:'0%'},
  {id:'magicien',label:'Magicien',image:'assets/avatar-magicien-v8.png',bg:'#173F4F',zoom:'100%',top:'0%'},
  {id:'royaux',label:'Duo royal',image:'assets/avatar-royaux-v8.png',bg:'#3D2148',zoom:'100%',top:'0%'},
  {id:'ver',label:'Ver',image:'assets/avatar-ver-v8.png',bg:'#182E58',zoom:'100%',top:'0%'},
  {id:'gif-clap',label:'Clap !',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/Claqueta2.gif',source:'https://commons.wikimedia.org/wiki/File:Claqueta2.gif',author:'MdeVicente',license:'CC0',bg:'#25364b',fallback:'assets/avatar-gobelin-v8.png'},
  {id:'gif-bobine',label:'Bobine',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/Bobine.gif',source:'https://commons.wikimedia.org/wiki/File:Bobine.gif',author:'Liliandu45',license:'CC0',bg:'#38234d',fallback:'assets/avatar-poule-v8.png'},
  {id:'gif-popcorn',label:'Popcorn',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/Slowmotion_popcorn.gif',source:'https://commons.wikimedia.org/wiki/File:Slowmotion_popcorn.gif',author:'At09kg',license:'CC BY-SA 3.0',bg:'#331d36',fallback:'assets/avatar-ver-v8.png'},
  {id:'gif-decompte',label:'Décompte',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/10_seconds_countdown.gif',source:'https://commons.wikimedia.org/wiki/File:10_seconds_countdown.gif',author:'Pixelmaniac pictures',license:'Domaine public',bg:'#151728',fallback:'assets/avatar-magicien-v8.png'},
  {id:'gif-zoetrope',label:'Zootrope',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/Animation_de_Daisy-Muybridge-_par_un_Zootrope.gif',source:'https://commons.wikimedia.org/wiki/File:Animation_de_Daisy-Muybridge-_par_un_Zootrope.gif',author:'Bernard de Go Mars',license:'CC BY-SA 4.0',bg:'#273a4a',fallback:'assets/avatar-royaux-v8.png'},
  {id:'gif-projecteur',label:'Projecteur',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/M%C3%A9canisme_du_cin%C3%A9matographe_des_fr%C3%A8res_Lumi%C3%A8re.gif',source:'https://commons.wikimedia.org/wiki/File:M%C3%A9canisme_du_cin%C3%A9matographe_des_fr%C3%A8res_Lumi%C3%A8re.gif',author:'Bernard de Go Mars / Starcheuch',license:'CC BY-SA 4.0',bg:'#1f3241',fallback:'assets/avatar-gobelin-v8.png'},
  {id:'gif-camera',label:'Caméra',animated:true,image:'https://commons.wikimedia.org/wiki/Special:FilePath/Moviecam_schematic_animation.gif',source:'https://commons.wikimedia.org/wiki/File:Moviecam_schematic_animation.gif',author:'Joram van Hartingsveldt',license:'CC BY-SA (voir source)',bg:'#322945',fallback:'assets/avatar-poule-v8.png'}
];
const reducedAvatarMotion=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||false;
function avatarSrc(a){return a.animated&&reducedAvatarMotion() ? a.fallback : a.image;}
function avatarFor(p=profile()){return AVATARS.find(a=>a.id===p?.settings?.avatar)||AVATARS[0]}
function syncAvatar(){
  const choice=avatarFor(),button=$('avatarButton');
  if(!button)return;
  button.style.setProperty('--avatar-bg',choice.bg);
  button.style.setProperty('--portrait-zoom',choice.zoom||'100%');
  button.style.setProperty('--portrait-top',choice.top||'0%');
  button.setAttribute('aria-label','Choisir un avatar');
  const img=button.querySelector('img');
  if(img && img.dataset.avatarId!==choice.id){
    img.dataset.avatarId=choice.id;
    img.onerror=null;
    if(choice.animated){img.onerror=()=>{img.onerror=null;img.src=choice.fallback;img.title='GIF temporairement indisponible';};}
    img.src=avatarSrc(choice);
    img.alt='';
  }
}

const COUNTRIES_OK=new Set(['United States of America','United States','USA','Canada','United Kingdom','UK','Great Britain','Australia','New Zealand','Ireland']);
const COUNTRY_CODES_OK=new Set(['Q30','Q16','Q145','Q408','Q664','Q27']);
const ENGLISH_CODE='Q1860';
const BLOCKED_WORDS=['India','China','Hong Kong','Taiwan','Pakistan','Bangladesh','Nepal'];
const num=n=>new Intl.NumberFormat('fr-CA').format(n||0);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const val=x=>String(x??'').trim();
const normalizeName=x=>String(x||'').normalize('NFKC').toLocaleLowerCase('fr').trim();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const pick=a=>a[Math.floor(Math.random()*a.length)];
const cleanGen=g=>({ 'Sci-Fi':'Science Fiction','Science-Fiction':'Science Fiction','Science fiction':'Science Fiction','Sci Fi':'Science Fiction', 'Romantic Comedy':'Romance','TV Movie':'Drama','Music':'Music', 'Musical':'Musical'}[g]||g);
const unique=a=>[...new Set(a)];
let dbPromise=null;function openDB(){if(dbPromise)return dbPromise;dbPromise=new Promise((ok,bad)=>{if(!('indexedDB'in window))return bad(Error('IndexedDB non disponible'));let req=indexedDB.open('cinespin_v5_db',1);req.onupgradeneeded=()=>req.result.createObjectStore('stuff');req.onsuccess=()=>ok(req.result);req.onerror=()=>bad(req.error)});return dbPromise}
async function dbGet(key){try{const db=await openDB();return await new Promise((ok,bad)=>{const t=db.transaction('stuff','readonly'),r=t.objectStore('stuff').get(key);r.onsuccess=()=>ok(r.result);r.onerror=()=>bad(r.error)})}catch(e){return null}}
async function dbSet(key,value){try{const db=await openDB();return await new Promise((ok,bad)=>{const t=db.transaction('stuff','readwrite');t.objectStore('stuff').put(value,key);t.oncomplete=()=>ok(true);t.onerror=()=>bad(t.error)})}catch(e){console.warn('Cache local:',e.message);return false}}
let profiles={};try{profiles=JSON.parse(localStorage.getItem(PROFILES_KEY)||'{}')}catch(e){}
const defaultProfile=name=>({name,watched:[],favorites:[],hidden:[],history:[],settings:{safe:false,sound:false},session:{movie:{genre:null,spins:0,candidate:null,confirmed:false,rotation:0},tv:{genre:null,spins:0,candidate:null,confirmed:false,rotation:0}},created:Date.now()});
let current=localStorage.getItem(ACTIVE_KEY)||null;
let mode='movie',route='play',data={movie:[],tv:[]},source={movie:'',tv:'',updated:'',error:'',loading:true,hfTotal:0,hfLoaded:0},loading=false,spinning=false,reelInterval=null,search='',genreFilter='',viewFilter='all',sort='votes',page=0;
let localCountries={};try{localCountries=JSON.parse(localStorage.getItem(COUNTRY_KEY)||'{}')}catch(e){}
let toastTimer=null,modalLocked=false, scrollLast=0;
function profile(){return profiles[current]||null}
function saveProfile(){try{localStorage.setItem(PROFILES_KEY,JSON.stringify(profiles));if(current)localStorage.setItem(ACTIVE_KEY,current)}catch(e){notify('Stockage plein. Exporte ta progression.')}}
function session(){let p=profile();return p?.session?.[mode]||{genre:null,spins:0,candidate:null,confirmed:false,rotation:0}}
function openModal(html,locked=false){modalLocked=locked;$('modalBody').innerHTML=html;$('modal').classList.remove('hidden');$('closeModal').style.display=locked?'none':'block'}
function closeModal(){if(modalLocked)return;$('modal').classList.add('hidden')}
function notify(t){$('toast').textContent=t;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3100)}
function getModeArray(){return data[mode]||[]}
function idFor(m){return (m.type||mode)+':'+m.id}
function isWatched(m){return !!profile()?.watched.includes(idFor(m))}
function isHidden(m){return !!profile()?.hidden.includes(idFor(m))}
function isFav(m){return !!profile()?.favorites.includes(idFor(m))}
function qualifies(m){if(!m)return false;let g=m.genres||[];if(g.some(x=>/documentary|news|talk|reality|game[- ]show|short|adult/i.test(x)))return false;if(m.adult)return false;if(m.type==='movie'&&m.year<2013)return false;if(m.type==='tv'&&m.year<2013)return false;return Number(m.rating)>=7.2&&Number(m.votes)>5000&&m.countryVerified===true&&m.englishVerified===true}
function qualifiesRT(m){return m.type==='movie'&&m.year>=2011&&Number(m.rtScore)>75&&Number(m.rtCount)>10000&&m.countryVerified===true&&m.englishVerified===true&&!m.genres.some(x=>/documentary/i.test(x))}
function profileSafe(){return !!profile()?.settings.safe}
function eligible(m,withSeen=false){if(!(qualifies(m)||qualifiesRT(m)))return false;if(profileSafe()&&(m.rating<7.5||m.votes<=30000)&&!(m.rtScore>=85&&m.rtCount>20000))return false;if(!withSeen&&(isWatched(m)||isHidden(m)))return false;return true}
function genreList(){const counts={};for(const m of getModeArray())if(eligible(m))for(const g of categoriesFor(m))counts[g]=(counts[g]||0)+1;return CATS.filter(g=>counts[g]>0).map(g=>({name:g,count:counts[g]}))}
function eligibleGenre(g){return getModeArray().filter(m=>categoriesFor(m).includes(g)&&eligible(m))}
function allCount(){return getModeArray().filter(m=>eligible(m,true)).length}
function userSeenCount(){return getModeArray().filter(m=>eligible(m,true)&&isWatched(m)).length}
function setRoute(r){if(spinning)return;closeDrawer();route=r;document.querySelectorAll('[data-route]').forEach(b=>b.classList.toggle('active',b.dataset.route===r));render();$('content-area').scrollIntoView({behavior:'smooth',block:'start'})}
function setMode(m){if(spinning)return;mode=m;page=0;search='';genreFilter='';$('modeMovie').classList.toggle('active',mode==='movie');$('modeTV').classList.toggle('active',mode==='tv');$('modeMovie').setAttribute('aria-pressed',mode==='movie');$('modeTV').setAttribute('aria-pressed',mode==='tv');render()}
function updateTop(){let p=profile();$('profileTop').textContent=p?.name||'Profil';syncAvatar();let c=getModeArray().filter(x=>eligible(x,true)),unseen=c.filter(x=>!isWatched(x)&&!isHidden(x));let finished=CATS.filter(g=>c.some(x=>categoriesFor(x).includes(g))&&!unseen.some(x=>categoriesFor(x).includes(g))).length;
const singular=mode==='movie'?'film':'série';$('heroPlay').firstChild.textContent=mode==='movie'?'TROUVER MON FILM ':'TROUVER MA SÉRIE ';$('heroMetrics').innerHTML=`<div class="metric"><strong>${num(unseen.length)}</strong><small>${singular}s à découvrir</small></div><div class="metric"><strong>${num(c.filter(isWatched).length)}</strong><small>Déjà ${mode==='movie'?'vus':'vues'}</small></div>`;
$('catalogStatus').innerHTML=`<i></i>${source.loading?'Importation '+num(source.hfLoaded)+' / '+num(source.hfTotal||'')+'…':num(c.length)+' '+singular+'s admissibles'}`;
$('catalogStatus').title=source.error||source[mode]||'Catalogue réel';
// CinéSpin V8.7 — galerie à défilement infini, affiches réelles uniquement.
// Les titres sont ordonnés du plus populaire au centre vers les bords.
refreshHeroGallery(c);

}
function showOnboard(msg=''){let takenKeys=Object.keys(profiles);openModal(`<img class="modal-mascot" src="assets/mascotte-popcorn.png" alt="Dragon CinéSpin"><div class="eyebrow">BIENVENUE AU CINÉMA</div><h2>QUEL NOM AU GÉNÉRIQUE ?</h2><p>Un pseudo suffit pour retenir ce que tu as vu. Les profils restent <b>sur cet appareil</b> : ce n’est pas un compte protégé ou synchronisé.</p>${msg?`<p class="notice-inline">${esc(msg)}</p>`:''}<label for="username">TON NOM D’UTILISATEUR</label><input class="field" id="username" maxlength="20" placeholder="ex. SeigneurDuPopcorn" autocomplete="nickname"><div class="btn-row"><button class="btn red" data-act="checkUsername">ENTRER ↗</button></div>${takenKeys.length?`<small>${takenKeys.length} profil(s) sur cet appareil. Pas de vol d'identité, même pour un film de braquage.</small>`:''}`,true);setTimeout(()=>$('username')?.focus(),100)}
function checkUsername(){const raw=val($('username')?.value),name=normalizeName(raw);if(!/^[\p{L}\p{N}_.-]{3,20}$/u.test(raw)){notify('3 à 20 caractères, lettres/chiffres et . _ -');return}let exist=Object.keys(profiles).find(k=>normalizeName(k)===name);if(exist){openModal(`<div class="eyebrow">ATTENTION, DOUBLE IDENTITÉ</div><h2>CE NOM EST DÉJÀ PRIS.</h2><p><b>${esc(profiles[exist].name)}</b> existe sur cet appareil. Ça sent le multivers.</p><div class="btn-row"><button class="btn primary" data-act="takeProfile" data-name="${esc(exist)}">C’EST MOI</button><button class="btn" data-act="chooseOther">CHOISIR UN AUTRE NOM</button></div><small>Sans mot de passe, « C’est moi » ouvre le profil local. Ne mets rien de sensible ici.</small>`,true);return}profiles[raw]=defaultProfile(raw);takeProfile(raw)}
function takeProfile(key){current=key;saveProfile();modalLocked=false;closeModal();updateTop();render();enrichMissingPosters();notify('Bienvenue '+profiles[key].name+'. Le popcorn est prévenu.')} 
function requireProfile(){if(!profile()){showOnboard();return false}return true}
function changeProfile(){closeDrawer();modalLocked=false;showOnboard()}
function showAvatarPicker(){
  if(!requireProfile())return;
  closeDrawer();
  const selected=avatarFor().id;
  const card=a=>`<button type="button" class="avatar-modal-choice${a.id===selected?' selected':''}${a.animated?' avatar-is-gif':''}" data-act="setAvatar" data-id="${esc(a.id)}" aria-label="Choisir ${esc(a.label)}${a.animated?' (GIF animé)':''}" aria-pressed="${a.id===selected}"><span class="avatar-swatch" style="--avatar-bg:${a.bg};--portrait-zoom:${a.zoom||'100%'};--portrait-top:${a.top||'0%'}"><img src="${esc(avatarSrc(a))}" data-avatar-gif="${a.animated?'1':'0'}" data-fallback="${esc(a.fallback||'')}" alt="" loading="lazy"></span>${a.animated?'<span class="avatar-gif-badge" aria-hidden="true">GIF</span>':''}${a.id===selected?'<span class="avatar-selected-mark" aria-hidden="true">✓</span>':''}${a.animated?`<span class="avatar-choice-label">${esc(a.label)}</span>`:''}</button>`;
  const illustrations=AVATARS.filter(a=>!a.animated).map(card).join('');
  const animations=AVATARS.filter(a=>a.animated).map(card).join('');
  const credits=AVATARS.filter(a=>a.animated).map(a=>`<li><a href="${esc(a.source)}" target="_blank" rel="noopener noreferrer">${esc(a.label)}</a> · ${esc(a.author)} · ${esc(a.license)}</li>`).join('');
  openModal(`<div class="eyebrow">PERSONNALISE TON PROFIL</div><h2>CHOISIS TON AVATAR.</h2><div class="avatar-section-title">LES ORIGINAUX <span>05</span></div><div class="avatar-modal-grid" role="group" aria-label="Avatars illustrés">${illustrations}</div><div class="avatar-section-title">GIF CINÉMA <span>07</span></div><div class="avatar-modal-grid avatar-gif-grid" role="group" aria-label="GIF animés sur le cinéma">${animations}</div><p class="avatar-online-note">Les GIF viennent du web et demandent une connexion. Si l’un fait sa diva, l’avatar classique prend le relais.</p><details class="avatar-credits"><summary>Sources et licences des GIF</summary><ul>${credits}</ul><small>Fichiers consultés sans modification. Licences détaillées sur les pages liées.</small></details>`,false);
  $('modalBody').querySelectorAll('.avatar-is-gif img').forEach(img=>img.addEventListener('error',()=>{
    img.src=img.dataset.fallback||'assets/avatar-gobelin-v8.png';
    img.classList.add('gif-failed');
  },{once:true}));
}

function setAvatar(id){
  const p=profile(),choice=AVATARS.find(a=>a.id===id);
  if(!p||!choice)return;
  p.settings=p.settings||{};
  p.settings.avatar=choice.id;
  saveProfile();modalLocked=false;closeModal();updateTop();notify('Avatar mis à jour.');
}

function markSeen(id,yes=null){if(!requireProfile())return;let m=data.movie.find(x=>id==='movie:'+x.id)||data.tv.find(x=>id==='tv:'+x.id);if(!m)return;let p=profile();let checked=yes===null?!p.watched.includes(id):yes;p.watched=p.watched.filter(x=>x!==id);if(checked)p.watched.push(id);if(checked)p.history.unshift({id,at:Date.now(),action:'vu'});if(p.session[m.type]?.candidate===m.id&&checked)p.session[m.type].candidate=null;saveProfile();notify(checked?'Noté comme vu. Bonne nuit, '+p.name+' 🍿':'Remis dans le jeu.');render()}
function toggleFavorite(id){let p=profile();if(!p)return;p.favorites=p.favorites.includes(id)?p.favorites.filter(x=>x!==id):[...p.favorites,id];saveProfile();render();notify(p.favorites.includes(id)?'Mis en favori ❤️':'Favori retiré')}
function toggleHidden(id){let p=profile();if(!p)return;p.hidden=p.hidden.includes(id)?p.hidden.filter(x=>x!==id):[...p.hidden,id];saveProfile();render();notify(p.hidden.includes(id)?'Ce titre a été banni du royaume.':'Exil terminé.');}
function resetSession(m=mode){const p=profile();if(!p)return;p.session[m]={genre:null,spins:0,candidate:null,confirmed:false,rotation:0};saveProfile();render()}
function playSound(){if(!profile()?.settings.sound||matchMedia('(prefers-reduced-motion: reduce)').matches)return;try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const a=new C(),o=a.createOscillator(),g=a.createGain();o.type='triangle';o.frequency.setValueAtTime(540,a.currentTime);o.frequency.exponentialRampToValueAtTime(800,a.currentTime+.12);g.gain.setValueAtTime(.0001,a.currentTime);g.gain.exponentialRampToValueAtTime(.04,a.currentTime+.025);g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+.22);o.connect(g);g.connect(a.destination);o.start();o.stop(a.currentTime+.23);setTimeout(()=>a.close(),450)}catch(e){}}
function nextJoke(){return pick(WIT)}
/* Data parsing */
function splitCountries(s){if(Array.isArray(s))return s.map(x=>typeof x==='string'?x:x?.name).filter(Boolean);let txt=val(s);if(!txt)return[];try{const j=JSON.parse(txt);if(Array.isArray(j))return j.map(x=>x?.name||x).filter(Boolean)}catch(e){}return txt.split(/[,;|]/).map(x=>x.trim()).filter(Boolean)}
function checkCountry(names){let good=names.some(x=>COUNTRIES_OK.has(x));let blocked=names.some(x=>BLOCKED_WORDS.some(y=>x.toLowerCase().includes(y.toLowerCase())));return !!good&&!blocked}
function toPosterPath(p){p=val(p);if(!p)return'';if(p.startsWith('/'))return 'https://image.tmdb.org/t/p/w500'+p;return /^https:\/\//.test(p)?p:''}
function fromHF(row){const r=row.row||row;let y=Number(String(r.release_date||'').slice(0,4));let genres=unique(String(r.genres||'').split(',').map(s=>cleanGen(s.trim())).filter(g=>PALETTE[g]));let countries=splitCountries(r.production_countries);let imdb=val(r.tconst);if(!/^tt\d+$/.test(imdb)||r.adult===true||String(r.status).toLowerCase()!=='released'||y<2013||Number(r.averageRating)<7.2||Number(r.numVotes)<=5000||!genres.length||/documentary|reality|news|talk/i.test(String(r.genres)))return null;
 if(y>2026||val(r.original_language)!=='en'||!checkCountry(countries))return null;return {id:imdb,title:val(r.title),type:'movie',year:y,rating:Number(r.averageRating),votes:Number(r.numVotes),runtime:Number(r.runtime)||null,genres,poster:toPosterPath(r.poster_path),overview:val(r.overview),tagline:val(r.tagline),cast:val(r.cast),tmdbId:Number(r.id)||null,origin:'HF/TMDB + IMDb',sourceDate:'2026',countries,language:'en',countryVerified:true,englishVerified:true,adult:false}}
function fromMirror(row,fields){const o={};fields.forEach((f,i)=>o[f]=row[i]);let type=o.type==='movie'?'movie':(o.type==='tv_series'||o.type==='tv_miniseries')?'tv':null;if(!type||!/^tt\d+$/.test(o.id||''))return null;let year=Number(o.year),votes=Number(o.votes),rating=Number(o.rating);if(year<2013||year>2027||votes<=5000||rating<7.2||Number(o.is_adult)===1)return null;let genres=unique(String(o.genres||'').split(/[,|]/).map(s=>cleanGen(s.trim())).filter(x=>PALETTE[x]));if(!genres.length||/documentary|reality|news|talk/i.test(o.genres))return null;let cached=localCountries[o.id];let okay=cached?.status==='ok';return {id:o.id,title:o.title||o.original_title,type,year,rating,votes,genres,runtime:Number(o.runtime)||null,poster:toPosterPath(o.poster),overview:'',tagline:'',origin:'IMDb — copie archivée',sourceDate:'2026-08-17',countries:cached?.countries||[],language:okay?'en':'unknown',countryVerified:okay,englishVerified:okay,cast:o.cast||'',tmdbId:null,adult:false}}
function mergeTitles(originals,extras){const map=new Map();for(const m of [...originals,...extras]){if(!m)continue;const prev=map.get(m.id);if(!prev){map.set(m.id,m);continue}const preferred=Number(!!m.countryVerified)+Number(!!m.poster)+Number(!!m.overview),old=Number(!!prev.countryVerified)+Number(!!prev.poster)+Number(!!prev.overview);const rtExtra={rtScore:m.rtScore||prev.rtScore||null,rtCount:m.rtCount||prev.rtCount||null,rtUrl:m.rtUrl||prev.rtUrl||null};map.set(m.id,preferred>=old?{...prev,...m,overview:m.overview||prev.overview,poster:m.poster||prev.poster,tmdbId:m.tmdbId||prev.tmdbId,genres:unique([...(m.genres||[]),...(prev.genres||[])]),...rtExtra}:{...m,...prev,overview:prev.overview||m.overview,poster:prev.poster||m.poster,tmdbId:prev.tmdbId||m.tmdbId,genres:unique([...(m.genres||[]),...(prev.genres||[])]),...rtExtra})}
 return [...map.values()].filter(m=>m.type==='tv'||m.type==='movie').sort((a,b)=>b.votes-a.votes)}
async function readMirror(){let res=await fetch(SOURCE_MIRROR,{cache:'force-cache'});if(!res.ok)throw Error('Source IMDb '+res.status);let json;if(res.body&&typeof DecompressionStream!=='undefined'){const txt=await new Response(res.body.pipeThrough(new DecompressionStream('gzip'))).text();json=JSON.parse(txt)}else{const f=await fetch(SOURCE_MIRROR_JSON);if(!f.ok)throw Error('Source brute IMDb '+f.status);json=await f.json()}if(!Array.isArray(json.fields)||!Array.isArray(json.data))throw Error('Format IMDb inconnu');let arr=json.data.map(r=>fromMirror(r,json.fields)).filter(Boolean);return {arr,date:json.stats?.last_updated||'2026-08-17'}}
async function fetchWithTimeout(url,timeout=25000){const ct=new AbortController();const t=setTimeout(()=>ct.abort(),timeout);try{return await fetch(url,{signal:ct.signal,headers:{Accept:'application/json'}})}finally{clearTimeout(t)}}
async function readHF(){let params=new URLSearchParams({dataset:HF_DATASET,config:'default',split:'train',where:'"original_language"=\'en\' AND "averageRating">=7.2 AND "numVotes">5000 AND "release_date">=\'2013-01-01\' AND "adult"=false',offset:'0',length:'100'});
 async function getPage(offset){let pageParams=new URLSearchParams(params);pageParams.set('offset',String(offset));let url=HF+'?'+pageParams.toString();let e;for(let attempt=0;attempt<3;attempt++){try{let res=await fetchWithTimeout(url,22000);if(res.status===429||res.status===503){await sleep(1000*(attempt+1));continue}if(!res.ok)throw Error('HTTP '+res.status);return await res.json()}catch(err){e=err;await sleep(350*(attempt+1))}}throw e||Error('Source Hugging Face indisponible')}
 let first=await getPage(0);if(!Array.isArray(first.rows))throw Error('L’API retourne un format inconnu');let total=Number(first.num_rows_total)||first.rows.length;source.hfTotal=total;const max=Math.min(total,60000);let all=first.rows.map(fromHF).filter(Boolean);source.hfLoaded=first.rows.length;updateStatusOnly();let offsets=[];for(let o=100;o<max;o+=100)offsets.push(o);
 // Batched requests: avoid 100s of simultaneous calls to the public API.
 for(let i=0;i<offsets.length;i+=3){let group=await Promise.allSettled(offsets.slice(i,i+3).map(getPage));for(let j=0;j<group.length;j++){let r=group[j];if(r.status==='fulfilled'&&Array.isArray(r.value.rows)){all.push(...r.value.rows.map(fromHF).filter(Boolean));source.hfLoaded+=r.value.rows.length}else{source.error='Certaines pages de la source n’ont pas répondu.'}}
 updateStatusOnly();if(i%9===0)await sleep(80)}return all}
function updateStatusOnly(){if(!$('catalogStatus'))return;$('catalogStatus').innerHTML=`<i></i>${source.loading?'Recherche '+num(source.hfLoaded)+(source.hfTotal?' / '+num(source.hfTotal):''):'Catalogue chargé'}`;let l=$('loadText');if(l)l.textContent=source.hfLoaded?'Analyse des fiches '+num(source.hfLoaded)+' / '+num(source.hfTotal)+'…':'Lecture des notes, pays et affiches…'}
async function loadData(force=false){if(loading)return;loading=true;source.loading=true;source.error='';source.hfLoaded=0;source.hfTotal=0;const cached=!force?await dbGet('catalogV6'):null;if(cached?.movie?.length){data=cached;source.loading=false;source.movie=cached._source||'Cache sur cet appareil';source.tv='IMDb archivé';updateTop();render();loading=false;verifyCountryBatch();enrichMissingPosters();return}
 render();let mirrored=null,hfMovies=null;let mr=readMirror().then(x=>{mirrored=x;return x}).catch(e=>{source.error='IMDb : '+e.message;return null});let hr=readHF().then(x=>{hfMovies=x;return x}).catch(e=>{source.error+=(source.error?' | ':'')+'Source film enrichie : '+e.message;return null});await Promise.allSettled([mr,hr]);let baseMovies=mirrored?.arr.filter(x=>x.type==='movie')||[];let baseSeries=mirrored?.arr.filter(x=>x.type==='tv')||[];
 let old=await dbGet('customTitles')||[];let rt=await dbGet('rtTitles')||[];let movies=hfMovies?.length?mergeTitles(baseMovies,hfMovies):baseMovies;
 data={movie:mergeTitles(movies,old.filter(x=>x.type==='movie').concat(rt)),tv:mergeTitles(baseSeries,old.filter(x=>x.type==='tv')),_source:hfMovies?.length?'TMDB + IMDb (données combinées)':'IMDb — instantané du '+(mirrored?.date||'2026-08-17')};
 source.movie=hfMovies?.length?'IMDb + TMDB / anglais/pays vérifiés':mirrored?.date?'IMDb archivé · pays à vérifier':'Indisponible';source.tv='IMDb archivé · pays Wikidata';source.loading=false;loading=false;await dbSet('catalogV6',data);updateTop();render();if(!hfMovies?.length&&baseMovies.length)notify('Source enrichie indisponible. Catalogue IMDb de secours utilisé.');if(!data.movie.length&&!data.tv.length)notify('Catalogue indisponible : impossible de vérifier les films.');verifyCountryBatch();enrichMissingPosters();}
/* For archived source entries with no geography, verify Wikidata in small batches. Unverified entries NEVER enter the roulette. */
let verifyingCountries=false;async function verifyCountryBatch(){if(verifyingCountries)return;let candidates=[...data.movie,...data.tv].filter(m=>!m.countryVerified&&!localCountries[m.id]&&m.id&&/^tt\d+$/.test(m.id));if(!candidates.length)return;verifyingCountries=true;let changed=0;try{for(let i=0;i<candidates.length;i+=55){let chunk=candidates.slice(i,i+55),ids=chunk.map(m=>JSON.stringify(m.id)).join(' ');let q='SELECT ?imdb ?country ?language WHERE { VALUES ?imdb { '+ids+' } ?x <http://www.wikidata.org/prop/direct/P345> ?imdb . OPTIONAL { ?x <http://www.wikidata.org/prop/direct/P495> ?country . } OPTIONAL { ?x <http://www.wikidata.org/prop/direct/P364> ?language . } }';let u='https://query.wikidata.org/sparql?format=json&query='+encodeURIComponent(q);let r=await fetchWithTimeout(u,25000);if(!r.ok)throw Error('Wikidata '+r.status);let j=await r.json(),found=new Map();for(const b of j.results?.bindings||[]){let id=b.imdb?.value;if(!id)continue;let record=found.get(id)||{countries:new Set(),langs:new Set()};if(b.country?.value)record.countries.add(b.country.value.split('/').pop());if(b.language?.value)record.langs.add(b.language.value.split('/').pop());found.set(id,record)}
 for(const m of chunk){let x=found.get(m.id);let blockedCodes=new Set(['Q668','Q148','Q8646','Q865','Q843','Q902','Q837']);let ok=!!x&&x.countries.size>0&&[...x.countries].some(c=>COUNTRY_CODES_OK.has(c))&&![...x.countries].some(c=>blockedCodes.has(c))&&x.langs.has(ENGLISH_CODE);localCountries[m.id]={status:ok?'ok':'excluded',countries:x?[...x.countries]:[],verifiedAt:Date.now()};m.countryVerified=ok;m.englishVerified=ok;if(ok)m.language='en';changed++}
 if(i%165===0){try{localStorage.setItem(COUNTRY_KEY,JSON.stringify(localCountries))}catch(e){}updateTop();render();await dbSet('catalogV6',data)}await sleep(250)} }catch(e){source.error+=(source.error?' | ':'')+'Vérification des pays interrompue : '+e.message;console.warn(e)}finally{verifyingCountries=false;try{localStorage.setItem(COUNTRY_KEY,JSON.stringify(localCountries))}catch(e){}await dbSet('catalogV6',data);updateTop();render()}}
/* Rendering */
function wheelSVG(list){if(!list.length)return'<div class="empty-stage"><h3>Plus de genres.</h3><p>Tu as épuisé le catalogue. Le canapé te félicite.</p></div>';const n=list.length,step=360/n,r=183,cx=200,cy=200;let paths='',texts='';
for(let i=0;i<n;i++){const a=(-90+i*step)*Math.PI/180,b=(-90+(i+1)*step)*Math.PI/180;let x1=cx+r*Math.cos(a),y1=cy+r*Math.sin(a),x2=cx+r*Math.cos(b),y2=cy+r*Math.sin(b);
paths+=`<path d="M200 200 L${x1.toFixed(2)} ${y1.toFixed(2)} A${r} ${r} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)} Z" fill="${GENRE_COLORS[list[i].name]}" stroke="#171524" stroke-width="2"/>`;
let angle=-90+(i+.5)*step,rad=angle*Math.PI/180,rr=115,x=cx+rr*Math.cos(rad),y=cy+rr*Math.sin(rad);let rot=angle;if(rot>90&&rot<270)rot-=180;if(rot<-90&&rot>-270)rot+=180;let label=NAMES[list[i].name]||list[i].name;
texts+=`<text x="${x.toFixed(2)}" y="${y.toFixed(2)}" text-anchor="middle" dominant-baseline="central" font-family="Poppins,Arial,sans-serif" font-weight="800" font-size="${label.length>13?'12':'14'}" fill="${list[i].name==='Thriller'?'#FFF8EA':'#191625'}" transform="rotate(${rot} ${x.toFixed(2)} ${y.toFixed(2)})">${esc(label)}</text>`}
return `<div class="wheel-shell"><div class="wheel-pointer"></div><svg viewBox="0 0 400 400" role="img" aria-label="Roue de ${n} genres"><circle cx="200" cy="200" r="194" fill="#191625"/><g id="wheelDisk" class="wheel-disk" style="transform:rotate(${session().rotation||0}deg)">${paths}${texts}</g></svg><div class="wheel-center"><span>✦</span></div></div>`}
function colorContrast(name){return PALETTE[name]||'#ffd34f'}
function revealGenreCard(g){if(!g)return'';let v=eligibleGenre(g).length;return `<div class="genre-compact" style="--genre:${GENRE_COLORS[g]||'#FFD34F'}"><img src="${prizeImage(g)}" alt="Illustration du genre ${esc(NAMES[g]||g)}"><div><small>GENRE VALIDÉ</small><h3>${esc(NAMES[g]||g)}</h3><p>${num(v)} ${mode==='movie'?'films':'séries'} disponibles</p></div><button class="btn tiny" data-act="startOver">Changer</button></div>`}
function showPrize(g){let v=eligibleGenre(g).length,second=session().spins>=2;openModal(`<div class="prize-popup" style="--genre:${GENRE_COLORS[g]||'#FFD34F'}"><div class="prize-eyebrow">TON GENRE</div><div class="prize-illustration"><img src="${prizeImage(g)}" alt="Illustration : ${esc(NAMES[g]||g)}"></div><h2>${esc(NAMES[g]||g)}</h2><p>${num(v)} ${mode==='movie'?'films':'séries'} admissibles</p></div><div class="prize-actions"><button class="btn primary" data-act="prizeConfirm">VALIDER CE GENRE ↗</button>${!second?'<button class="btn secondary" data-act="prizeReroll">DEUXIÈME ESSAI ↻</button>':''}</div>`,false)}
function formatVotes(v){return num(v)}
function posterMarkup(m,cls='film-poster'){if(m.poster)return `<img class="${cls}" src="${esc(m.poster)}" alt="Affiche de ${esc(m.title)}" loading="lazy" onerror="this.onerror=null;this.src='assets/poster-fallback.svg'">`;return `<div class="poster-fallback ${cls}"><span>🎬</span><b>Affiche indisponible</b></div>`}
function genrePitch(m){let g=m.genres[0];const t={Action:'Du rythme, des enjeux et pas le temps de checker ton téléphone.',Adventure:'Pour voyager sans payer le supplément bagage.',Animation:'Quand l’animation a des choses à raconter aux grands aussi.',Biography:'Une histoire vraie qui méritait un grand écran.',Comedy:'Pour rire. Ou au minimum oublier ton lundi.',Crime:'De quoi soupçonner tout le monde, même ton chat.',Drama:'Des émotions. Non, ce n’est pas une menace.',Family:'La soirée qui met (presque) tout le monde d’accord.',Fantasy:'Un peu de magie, beaucoup de problèmes.',History:'L’histoire, mais avec un meilleur montage.',Horror:'Tu voulais dormir ? Ambitieux.',Music:'Monte le volume. Les voisins survivront.',Mystery:'Tu peux deviner la fin. Tu peux essayer.',Romance:'Des sentiments. Prépare ta défense.', 'Science Fiction':'Une bonne raison de questionner la réalité.',Sport:'Même assis sur ton divan, tu peux gagner.',Thriller:'Le suspense est offert, le repos non.',War:'Pour les grandes histoires et les décisions impossibles.',Western:'Un duel, de la poussière et des regards lourds de sens.'};return t[g]||'Pour le plaisir du cinéma, tout simplement.'}
function conciseText(m){let text=val(m.overview);if(text){let s=text.replace(/\s+/g,' ').trim();return s.length>156?s.slice(0,153).replace(/\s+\S*$/,'')+'…':s}if(m.tagline)return m.tagline;return genrePitch(m)}
function editorialWhy(m){return `<strong>Pourquoi il est admissible</strong><p>${m.rating>0?'IMDb '+m.rating.toFixed(1)+'/10 · '+num(m.votes)+' votes.':'Rotten Tomatoes '+num(m.rtScore)+' % public · '+num(m.rtCount)+' évaluations.'} ${m.countryVerified?'Production et langue vérifiées.':''} Ce classement ne prétend pas résumer les critiques.</p>`}
function sourceReview(m){return '<strong>Tendances des avis positifs</strong><p id="reviewArea">Pour afficher de véritables tendances d’avis, configure une clé TMDB dans Réglages. Aucune critique inventée ici.</p><button class="btn tiny no-flex" data-act="getReviews" data-id="'+esc(idFor(m))+'">Analyser les avis ↗</button>'}
function currentMovie(){const id=session().candidate;if(!id)return null;return getModeArray().find(x=>x.id===id)||null}
function identityCard(kind='popcorn',label='EN APARTÉ',title='La mascotte a quelque chose à dire.',copy='Promis, cette phrase sert à quelque chose.'){const map={popcorn:['assets/mascotte-popcorn.png','La mascotte CinéSpin mange du popcorn','tone-yellow'],tv:['assets/mascotte-television.png','La mascotte CinéSpin regarde un film','tone-cream'],sleep:['assets/mascotte-sieste.png','La mascotte CinéSpin dort','tone-dark']};const data=map[kind]||map.popcorn;return `<aside class="identity-card ${data[2]}"><img src="${data[0]}" alt="${data[1]}"><div><small>${label}</small><h3>${title}</h3><p>${copy}</p></div></aside>`}
function movieResult(m){if(!m)return'';let year=m.year+(m.runtime?' · '+m.runtime+' min':'');return `<div class="picked-result"><div class="picked-poster">${posterMarkup(m)}</div><div class="picked-info"><div class="winner-label">LE TITRE TIRÉ</div><h3>${esc(m.title)}</h3><p class="picked-sub">${year} · ${esc(m.genres.slice(0,2).map(g=>NAMES[g]||g).join(' / '))}</p><div class="picked-score"><strong>${m.rating>0?'★ '+Number(m.rating).toFixed(1):'🍅 '+m.rtScore+'%'}</strong><small>${m.rating>0?'IMDb · '+num(m.votes)+' votes':'Rotten Tomatoes · '+num(m.rtCount)+' évaluations'}</small></div>${m.overview?`<p class="picked-synopsis">${esc(conciseText(m))}</p>`:''}<details class="picked-more"><summary>Pourquoi ce choix ?</summary>${editorialWhy(m)}<div class="extra-reviews">${sourceReview(m)}</div><a href="https://www.imdb.com/title/${encodeURIComponent(m.id)}/" target="_blank" rel="noopener">Voir la fiche IMDb ↗</a></details></div></div><div class="result-actions"><button class="btn primary" data-act="chosen">🍿 ON LE REGARDE</button><button class="btn red" data-act="reroll">PAS CE SOIR, SATAN ↻</button><button class="btn" data-act="watchedCurrent">✓ DÉJÀ VU</button></div><div class="secondary-actions"><button data-act="favoriteCurrent">${isFav(m)?'♥ En favori':'♡ Ajouter aux favoris'}</button><button data-act="hideCurrent">Masquer ce titre</button></div>`}
function slotMarkup(){let m=currentMovie();if(m)return movieResult(m);return `<div class="slot" id="movieSlot"><div class="slot-row"><span>${mode==='movie'?'DES FILMS':'DES SÉRIES'}</span></div><div class="slot-row selected"><span id="slotCenterText">À TOI DE JOUER</span></div><div class="slot-row"><span>UN SEUL GAGNANT</span></div></div><div class="slot-footer">${num(eligibleGenre(session().genre).length)} titres participent au tirage.</div><div class="btn-row"><button class="btn red" data-act="spinTitle">TIRER UN ${mode==='movie'?'FILM':'SÉRIE'} ↗</button></div>`}
function renderPlay(){let sg=session(),opts=genreList(),currentGenre=sg.genre,n=sg.spins,step2=sg.confirmed,screen=$('screen');let hasTitles=getModeArray().some(x=>eligible(x,true));
if(!hasTitles){screen.innerHTML=`<div class="load-panel"><h2>${source.loading?'Chargement du catalogue…':'Aucun titre vérifié disponible.'}</h2><p>${source.loading?'Recherche de films selon tes critères.':'Le filtre privilégie les productions anglophones nord-américaines et exclut les pays demandés.'}</p><small>${esc(source.error||'Lance une actualisation si rien n’apparaît.')}</small><div class="btn-row"><button class="btn primary" data-act="refresh">Actualiser</button></div></div>`;return}
let decisions=!n?'<button class="btn primary" data-act="spinGenre">TOURNER LA ROUE ↗</button>':!step2?`<button class="btn primary" data-act="confirmGenre">GARDER ${esc(NAMES[currentGenre]||currentGenre)} ✓</button>${n<2?'<button class="btn" data-act="spinGenre">DEUXIÈME ESSAI ↻</button>':''}`:'';
if(!step2){screen.innerHTML=`<div class="section-top"><div><span class="section-index">ÉTAPE 1 / 2</span><h2 class="section-title">CHOISIS TON GENRE.</h2></div><p class="section-hint">Deux tours maximum. Le premier peut être un accident.</p></div><article class="stage-card genre-stage"><div class="stage-heading"><span>${opts.length} genres disponibles</span><span>${n} / 2 tours</span></div>${wheelSVG(opts)}${currentGenre?`<div class="selected-genre">Genre tiré : <strong>${esc(NAMES[currentGenre]||currentGenre)}</strong></div>`:''}<div class="btn-row">${decisions}</div></article>${identityCard('popcorn','RÈGLE DU JEU','Tu gardes ou tu relances.','Si le premier genre ne te parle pas, tu as un seul droit d’appel. Après ça, le cinéma tranche.')}`;return}
const asideTitle=currentMovie()?'Le débat peut fermer boutique.':'Le genre est verrouillé.';
const asideCopy=currentMovie()?'Tu peux toujours relancer, mais au moins tu sais exactement ce que tu refuses.':'Tu piges maintenant parmi les titres admissibles de ce genre. Rien d’autre, rien de flou.';
screen.innerHTML=`<div class="section-top"><div><span class="section-index">ÉTAPE 2 / 2</span><h2 class="section-title">${currentMovie()?'ON REGARDE ÇA ?':'TIRE UN TITRE.'}</h2></div><p class="section-hint">Un seul gagnant. Le scroll est officiellement suspendu.</p></div>${revealGenreCard(currentGenre)}<article class="stage-card final-stage">${slotMarkup()}</article>${identityCard(currentMovie()?'sleep':'tv',currentMovie()?'VERDICT':'SÉLECTION EN COURS',asideTitle,asideCopy)}`}
function spinGenre(){if(spinning)return;let p=profile(),sg=session(),opts=genreList();if(!p||sg.confirmed||sg.spins>=2||!opts.length)return;spinning=true;
let idx=Math.floor(Math.random()*opts.length),choice=opts[idx].name,deg=360/opts.length,goal=-(idx+.5)*deg;let delta=((goal-(sg.rotation%360))%360+360)%360;sg.rotation=(sg.rotation||0)+360*5+delta;let disk=$('wheelDisk');if(disk)disk.style.transform=`rotate(${sg.rotation}deg)`;document.querySelectorAll('[data-act]').forEach(b=>b.disabled=true);
setTimeout(()=>{sg.genre=choice;sg.spins++;sg.candidate=null;saveProfile();spinning=false;render();playSound();showPrize(choice)},3400)}
function confirmGenre(){let s=session();if(!s.genre||s.confirmed)return;s.confirmed=true;saveProfile();render();setTimeout(()=>$('slotPanel')?.scrollIntoView({behavior:'smooth',block:'center'}),100);notify('Prix débloqué : '+(NAMES[s.genre]||s.genre))}
function spinTitle(){if(spinning)return;let s=session();if(!s.confirmed)return;let all=eligibleGenre(s.genre);if(!all.length){notify('Genre épuisé. Félicitations, tu as tout regardé.');resetSession();return}spinning=true;let winner=pick(all);let slot=$('movieSlot');let center=$('slotCenterText');if(!slot||!center){spinning=false;return}slot.classList.add('spinning');document.querySelectorAll('[data-act]').forEach(b=>b.disabled=true);let t=0;reelInterval=setInterval(()=>{t++;center.textContent=pick(all).title;if(t>40){clearInterval(reelInterval);reelInterval=null;center.textContent=winner.title;slot.classList.remove('spinning');s.candidate=winner.id;spinning=false;saveProfile();render();playSound();notify('Le verdict est tombé.');if(profile()?.settings.tmdbKey)setTimeout(()=>getReviews(idFor(winner)),250);}},65)}
function startOver(){openModal(`<div class="eyebrow">NOUVELLE SOIRÉE</div><h2>ON RECOMMENCE ?</h2><p>Tu vas réinitialiser tes deux essais de genre. Les films déjà vus resteront sauvegardés. La mémoire, elle, est moins facile à effacer.</p><div class="btn-row"><button class="btn red" data-act="yesStartOver">OUI, NOUVELLE PARTIE</button><button class="btn" data-act="closeModal">ANNULER</button></div>`,false)}
function chosen(){const m=currentMovie();if(!m)return;let p=profile();p.history.unshift({id:idFor(m),at:Date.now(),action:'choisi'});saveProfile();openModal(`${posterMarkup(m,'modal-mascot')}<div class="eyebrow">✦ SOIRÉE VALIDÉE</div><h2>${esc(m.title)}</h2><p>Le débat est terminé. À moins de vouloir finir dans un documentaire sur les couples qui n'arrivent pas à choisir.</p><div class="btn-row"><button class="btn mint" data-act="chosenWatched">✓ JE L’AI REGARDÉ</button><button class="btn primary" data-act="closeModal">C'EST PARTI 🍿</button></div>`,false);if(profile()?.settings.tmdbKey)setTimeout(()=>getReviews(idFor(m)),250)}
function renderCatalog(seenOnly=false){let c=getModeArray().filter(x=>eligible(x,true));if(seenOnly)c=c.filter(isWatched);else c=c.filter(x=>!isHidden(x));let allGenres=unique(c.flatMap(x=>x.genres).filter(g=>PALETTE[g])).sort();if(genreFilter)c=c.filter(x=>x.genres.includes(genreFilter));if(search){let q=normalizeName(search);c=c.filter(x=>normalizeName(x.title).includes(q)||normalizeName(x.cast||'').includes(q))}if(viewFilter==='unwatched'&&!seenOnly)c=c.filter(x=>!isWatched(x));if(viewFilter==='watched'&&!seenOnly)c=c.filter(isWatched);if(viewFilter==='favorite'&&!seenOnly)c=c.filter(isFav);c.sort((a,b)=>sort==='rating'?b.rating-a.rating:sort==='year'?b.year-a.year:sort==='title'?a.title.localeCompare(b.title):b.votes-a.votes);
 let pages=Math.max(1,Math.ceil(c.length/24));page=Math.min(page,pages-1);let subset=c.slice(page*24,page*24+24);const screen=$('screen');
 const aside=seenOnly
   ? identityCard('sleep','HISTORIQUE','Tu as déjà vu tout ça.','Personne ne te juge. Sauf peut-être ton toi de 2018.')
   : identityCard('tv','MODE MANUEL','Oui, tu peux encore fouiller à la main.','Quand tu veux contrôler la soirée au lieu de la laisser rouler, c’est ici.');
 screen.innerHTML=`<div class="section-top"><div><div class="section-index">${seenOnly?'HISTORIQUE':'FILMS ET SÉRIES'}</div><h2 class="section-title">${seenOnly?'DÉJÀ VUS.':'LE CATALOGUE.'}</h2></div><p class="section-hint">${seenOnly?'Chaque titre coché sort des tirages. Le système a de la mémoire.':'Recherche, filtre, trie. Ou retourne à la roue et laisse le destin travailler.'}</p></div>${aside}<div class="catalog-tools"><input class="field" id="catalogSearch" placeholder="Rechercher un titre / acteur…" value="${esc(search)}" aria-label="Rechercher"><select class="select" id="catalogGenre" aria-label="Genre"><option value="">Tous les genres</option>${allGenres.map(g=>`<option value="${esc(g)}" ${genreFilter===g?'selected':''}>${esc(NAMES[g]||g)}</option>`).join('')}</select><select class="select" id="catalogSort" aria-label="Tri"><option value="votes" ${sort==='votes'?'selected':''}>Plus populaires</option><option value="rating" ${sort==='rating'?'selected':''}>Mieux notés</option><option value="year" ${sort==='year'?'selected':''}>Plus récents</option><option value="title" ${sort==='title'?'selected':''}>Alphabétique</option></select></div>${!seenOnly?`<div class="btn-row filter-row"><button class="btn tiny ${viewFilter==='all'?'primary':''}" data-act="filterView" data-filter="all">Tous</button><button class="btn tiny ${viewFilter==='unwatched'?'primary':''}" data-act="filterView" data-filter="unwatched">À voir</button><button class="btn tiny ${viewFilter==='watched'?'primary':''}" data-act="filterView" data-filter="watched">Vus</button><button class="btn tiny ${viewFilter==='favorite'?'primary':''}" data-act="filterView" data-filter="favorite">♡ Favoris</button></div>`:''}<p class="catalog-count">${num(c.length)} ${mode==='movie'?'films':'séries'} affichés · Page ${page+1}/${pages}</p>${subset.length?`<div class="catalog-grid">${subset.map(movieCard).join('')}</div>`:`<div class="empty-stage"><div class="big-emoji">👻</div><h3>Rien dans la salle.</h3><p>Change un filtre. Ou accuse un fantôme, c’est plus satisfaisant.</p></div>`}<div class="pager"><button data-act="prevPage" ${page<=0?'disabled':''}>← Précédent</button><strong>${page+1} / ${pages}</strong><button data-act="nextPage" ${page>=pages-1?'disabled':''}>Suivant →</button></div>`;
 $('catalogSearch').addEventListener('input',e=>{const pos=e.target.selectionStart;search=e.target.value;page=0;renderCatalog(seenOnly);let el=$('catalogSearch');el.focus();el.setSelectionRange(pos,pos)});$('catalogGenre').addEventListener('change',e=>{genreFilter=e.target.value;page=0;renderCatalog(seenOnly)});$('catalogSort').addEventListener('change',e=>{sort=e.target.value;page=0;renderCatalog(seenOnly)})}
function movieCard(m){let id=idFor(m);return `<article class="movie-item"><div class="poster-shell">${posterMarkup(m,'poster-cover')}<span class="poster-tag">${m.votes>0?"★ "+m.rating.toFixed(1):"🍅 "+m.rtScore+"%"}</span></div><div class="movie-item-body"><h3>${esc(m.title)}</h3><p class="meta">${m.year} • ${num(m.votes)} votes</p><p class="item-summary">${esc(conciseText(m))}</p><div class="item-actions"><button data-act="toggleSeen" data-id="${esc(id)}" class="${isWatched(m)?'selected':''}">${isWatched(m)?'✓ VU':'+ VU'}</button><button data-act="toggleFav" data-id="${esc(id)}" class="${isFav(m)?'selected':''}">${isFav(m)?'♥':'♡'}</button><button data-act="showFilm" data-id="${esc(id)}">DÉTAILS</button></div></div></article>`}
function detailModal(id){const m=data.movie.concat(data.tv).find(x=>id===idFor(x));if(!m)return;openModal(`<div class="eyebrow">${m.year} · ${esc(m.genres.map(g=>NAMES[g]||g).join(' / '))}</div><h2>${esc(m.title)}</h2>${posterMarkup(m,'modal-mascot')}<p>${esc(conciseText(m))}</p><div class="stats-list">${m.votes>0?`<span>★ ${m.rating.toFixed(1)}/10</span><span>${num(m.votes)} votes IMDb</span>`:`<span>Score public RT : ${num(m.rtScore)}%</span><span>${num(m.rtCount)} évaluations</span>`}</div><div class="why">${editorialWhy(m)}</div><div class="why">${sourceReview(m)}</div><div class="btn-row"><button class="btn mint" data-act="toggleSeen" data-id="${esc(id)}">${isWatched(m)?'↩ PAS VU':'✓ DÉJÀ VU'}</button><button class="btn yellow" data-act="toggleFav" data-id="${esc(id)}">♡ FAVORI</button></div><p><a href="https://www.imdb.com/title/${encodeURIComponent(m.id)}/" target="_blank" rel="noopener">Vérifier sur IMDb ↗</a></p>`,false)}
function renderSettings(){const p=profile();let publicC=getModeArray().filter(m=>eligible(m,true));let missing=getModeArray().filter(m=>!m.countryVerified).length;let movieAll=data.movie.filter(m=>qualifies(m)||qualifiesRT(m));let serieAll=data.tv.filter(m=>qualifies(m));let moviePosters=movieAll.filter(m=>m.poster&&!invalidPosterIds.has(galleryPosterId(m))).length;$('screen').innerHTML=`<div class="section-top"><div><div class="section-index">TON CINÉMA, TES RÈGLES</div><h2 class="section-title">LA SALLE DE CONTRÔLE.</h2></div><p class="section-hint">Filtres, importation, profil et données : tout est ici, clairement.</p></div>${identityCard('sleep','PANNEAU TECHNIQUE','Ici, tu ajustes la machine.','Le hasard adore la discipline. Toi, pas forcément, mais il faudra faire équipe quand même.')}<div class="settings-grid"><section class="setting-card account-card"><h3>👤 TON PROFIL</h3><p><b>${esc(p?.name||'Invité')}</b> · enregistré seulement sur cet appareil.</p><div class="stats-list"><span>${num(p?.watched.length)} vus</span><span>${num(p?.favorites.length)} favoris</span><span>${num(p?.hidden.length)} masqués</span></div><button class="btn primary" data-act="changeProfile">CHANGER DE PROFIL</button><button class="btn" data-act="exportProgress">↓ EXPORTER MES DONNÉES</button><label for="progressFile">Importer une sauvegarde JSON</label><input type="file" id="progressFile" accept="application/json,.json"><button class="btn" data-act="importProgress">IMPORTER & FUSIONNER</button><small>Un pseudo n’est ni un mot de passe ni un compte en ligne : la même personne doit récupérer son fichier JSON pour changer d’appareil.</small></section>
 <section class="setting-card"><h3>🎯 LA SÉLECTION</h3><p>Mode standard : les critères IMDb originaux, sans raccourci. Si tu veux jouer sans risque, active le mode sévère.</p><label class="checkline"><input type="checkbox" id="safeMode" ${p?.settings.safe?'checked':''}><span>Mode « Valeurs sûres » : IMDb ≥7,5 et &gt;30 000 votes (ou RT qualifié avec &gt;20 000 avis et ≥85 %)</span></label><label class="checkline"><input type="checkbox" id="soundMode" ${p?.settings.sound?'checked':''}><span>Effets sonores discrets (désactivés par défaut)</span></label><div class="notice-inline"><b>Filtre pays/langue :</b> États-Unis, Canada, Royaume-Uni, Irlande, Australie et Nouvelle-Zélande seulement, anglais original confirmé. Aucune coproduction contenant d'autres pays n'est admise, notamment Chine et Inde. Aucun documentaire.</div></section>
 <section class="setting-card source-card"><h3>📚 LE VRAI CATALOGUE</h3><p>Films vérifiés : <b>${num(movieAll.length)}</b> · Séries vérifiées : <b>${num(serieAll.length)}</b>. ${num(missing)} titres de ce mode attendent une vérification ou n'ont pas de pays fiable.</p><p>Affiches recensées : <b>${num(moviePosters)}/${num(movieAll.length)}</b> films vérifiés (liens d’images, disponibilité externe non garantie).</p><p>Films : ${esc(source.movie||'En cours')}. Séries : ${esc(source.tv||'En cours')}. ${source.error?`<b>Attention :</b> ${esc(source.error)}`:''}</p><p>Objectif : <b>1000 films ou plus</b>, mais jamais artificiellement gonflé. Le nombre réel peut être inférieur selon la disponibilité des métadonnées et les critères.</p><div class="btn-row"><button class="btn primary" data-act="refresh">↻ RECHARGER LES SOURCES</button><button class="btn" data-act="recheck">↻ VÉRIFIER LES PAYS</button></div><small>Les données IMDb officielles sont mises à jour quotidiennement. La copie IMDb de secours date d'août 2026. L'API externe enrichie peut être indisponible.</small></section>
 <section class="setting-card"><h3>🎞️ MISE À JOUR IMDb</h3><p>Option pour importer les données officielles complètes. Télécharge <a href="https://datasets.imdbws.com/" target="_blank" rel="noopener">title.ratings.tsv.gz</a> et <a href="https://datasets.imdbws.com/" target="_blank" rel="noopener">title.basics.tsv.gz</a>. La lecture se fait sur ton appareil.</p><label for="imdbFiles">Les deux fichiers officiels</label><input type="file" id="imdbFiles" accept=".gz,.tsv" multiple><button class="btn primary" data-act="importIMDb">IMPORTER IMDb</button><small id="importIMDBstatus">Ce sont de gros fichiers : préfère le Wi-Fi et un ordinateur. Le filtre pays reste obligatoire.</small></section>
 <section class="setting-card"><h3>🍅 ROTTEN TOMATOES</h3><p>La liste complète des évaluations du public ne peut pas être obtenue librement de façon vérifiable. Si tu possèdes un CSV sourcé, importe les scores <b>Popcornmeter &gt;75 %</b>, &gt;10 000 évaluations, sortie après 2010.</p><div class="btn-row"><button class="btn" data-act="templateRT">↓ MODÈLE CSV</button></div><label for="rtFile">Fichier CSV (avec pays/langue vérifiés)</label><input type="file" id="rtFile" accept=".csv,text/csv"><button class="btn primary" data-act="importRT">IMPORTER LES SCORES PUBLIC</button><small id="rtStatus">Pas d’invention de score Rotten Tomatoes. Les données qui ne prouvent pas les seuils sont écartées.</small></section>
 <section class="setting-card"><h3>💬 VRAIS AVIS POSITIFS</h3><p>Les notes IMDb ne contiennent <b>pas</b> les textes des avis. Les résumés d'avis sont donc proposés séparément, uniquement quand des avis positifs réels sont accessibles via TMDB. La même clé permet de rechercher les affiches manquantes à partir de l’identifiant IMDb.</p><label for="tmdbKey">Ta clé TMDB (facultative)</label><input class="field" id="tmdbKey" placeholder="Clé API TMDB (usage personnel)" value="${esc(p?.settings.tmdbKey||'')}" autocomplete="off"><button class="btn" data-act="saveTmdbKey">ENREGISTRER LA CLÉ</button><small>La clé reste sur cet appareil, mais elle sera utilisée directement par ton navigateur. Ce n’est pas recommandé pour un site public partagé.</small><p><a href="https://developer.themoviedb.org/docs/getting-started" target="_blank" rel="noopener">Demander ta clé TMDB ↗</a></p></section>
 <section class="setting-card"><h3>🚫 TITRES MASQUÉS</h3><p>Ces titres ne participent plus au tirage. Tu peux les réinviter à la soirée.</p><div class="stats-list">${(p?.hidden||[]).slice(0,30).map(id=>{let m=data.movie.concat(data.tv).find(x=>idFor(x)===id);return `<span style="border-radius:7px;background:#fff;display:inline-flex;align-items:center;gap:7px">${esc(m?.title||id)} <button data-act="toggleHidden" data-id="${esc(id)}" aria-label="Rétablir ${esc(m?.title||id)}" style="font-size:16px;background:transparent;border:0">↩</button></span>`}).join('')||'<span>Aucun film banni. Pour le moment.</span>'}</div></section><section class="setting-card"><h3>🛟 SAUVEGARDE & SOURCES</h3><p>Les marques « Déjà vu » se répercutent immédiatement dans tous les genres. Les films masqués ne participent plus au tirage.</p><p><a href="https://developer.imdb.com/non-commercial-datasets/" target="_blank" rel="noopener">IMDb : données personnelles non commerciales ↗</a></p><p><a href="https://huggingface.co/datasets/HenryWaltson/TMDB-IMDB-Movies-Dataset" target="_blank" rel="noopener">Catalogue combiné IMDb/TMDB ↗</a></p><p><a href="https://www.wikidata.org/wiki/Property:P495" target="_blank" rel="noopener">Wikidata : pays de production ↗</a></p><p><a href="https://developer.themoviedb.org/docs/faq" target="_blank" rel="noopener">TMDB : attribution et images ↗</a></p><small>Information courtesy of IMDb (https://www.imdb.com). Used with permission.</small></section></div>`;
 $('safeMode').addEventListener('change',e=>{p.settings.safe=e.target.checked;saveProfile();resetSession();updateTop();notify(e.target.checked?'Mode Valeurs sûres activé. Le destin est en probation.':'Mode standard activé.')});$('soundMode').addEventListener('change',e=>{p.settings.sound=e.target.checked;saveProfile();notify(e.target.checked?'Ding. Les voisins sont prévenus.':'Silence sur le plateau.')})}
function render(){updateTop();if(!profile()){if($('modal').classList.contains('hidden'))showOnboard();return}if(route==='play')renderPlay();else if(route==='catalog')renderCatalog(false);else if(route==='seen')renderCatalog(true);else if(route==='settings')renderSettings();}
/* Local uploads and portability */
function downloadText(filename,contents,type='application/json'){const blob=new Blob([contents],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)}
function exportProgress(){let p=profile();if(!p)return;let safe={version:'5.0',exported: new Date().toISOString(),profile:{...p,settings:{...p.settings,tmdbKey:''}}};downloadText('cinespin-sauvegarde-'+p.name.replace(/[^\w-]/g,'_')+'.json',JSON.stringify(safe,null,2));notify('Sauvegarde prête à ranger. Pas dans le tiroir à chaussettes.')}
async function importProgress(){let file=$('progressFile')?.files?.[0];if(!file)return notify('Choisis un fichier JSON.');try{let json=JSON.parse(await file.text());let x=json.profile||json;if(!Array.isArray(x.watched)||!Array.isArray(x.hidden))throw Error('Format de sauvegarde non reconnu');let p=profile();p.watched=unique([...p.watched,...x.watched].filter(s=>typeof s==='string'));p.hidden=unique([...p.hidden,...x.hidden].filter(s=>typeof s==='string'));p.favorites=unique([...p.favorites,...(x.favorites||[])].filter(s=>typeof s==='string'));p.history=[...p.history,...(x.history||[])].filter(s=>s&&s.id).slice(0,3000);saveProfile();render();notify('Sauvegarde fusionnée. Personne ne disparaît du générique.')}catch(e){notify('Import impossible : '+e.message)}}
async function* lines(file){let stream=file.stream();if(file.name.endsWith('.gz')){if(typeof DecompressionStream==='undefined')throw Error('Décompression gzip non disponible');stream=stream.pipeThrough(new DecompressionStream('gzip'))}const reader=stream.pipeThrough(new TextDecoderStream()).getReader();let carry='';try{while(true){const {value,done}=await reader.read();if(done)break;carry+=value;let idx;while((idx=carry.indexOf('\n'))>=0){yield carry.slice(0,idx).replace(/\r$/,'');carry=carry.slice(idx+1)}}if(carry)yield carry}finally{reader.releaseLock()}}
async function importIMDb(){const files=[...($('imdbFiles')?.files||[])],ratingFile=files.find(f=>/title\.ratings\.tsv(\.gz)?$/i.test(f.name)),basicsFile=files.find(f=>/title\.basics\.tsv(\.gz)?$/i.test(f.name));if(!ratingFile||!basicsFile)return notify('Il faut title.ratings.tsv.gz ET title.basics.tsv.gz.');let status=$('importIMDBstatus');let counts={rating:0,matched:0};try{status.textContent='Lecture des notes…';const ratingMap=new Map();let first=true;for await(const line of lines(ratingFile)){if(first){first=false;continue}let [id,n,v]=line.split('\t');if(!id||Number(n)<7.2||Number(v)<=5000)continue;ratingMap.set(id,{rating:Number(n),votes:Number(v)});if(++counts.rating%25000===0)status.textContent=num(counts.rating)+' évaluations admissibles trouvées…'}let arr=[],idx=0;first=true;status.textContent='Lecture des fiches IMDb…';let existing=new Map([...data.movie,...data.tv].map(x=>[x.id,x]));for await(const line of lines(basicsFile)){if(first){first=false;continue}idx++;let cols=line.split('\t'),id=cols[0],r=ratingMap.get(id);if(!r)continue;let rawType=cols[1],type=rawType==='movie'?'movie':(rawType==='tvSeries'||rawType==='tvMiniSeries'?'tv':null);if(!type||Number(cols[4])===1||Number(cols[5])<2013||Number(cols[5])>2027)continue;let genres=unique(String(cols[8]||'').split(',').map(cleanGen).filter(g=>PALETTE[g]));if(!genres.length||/documentary|talk|reality|news/i.test(cols[8]))continue;let prev=existing.get(id),country=localCountries[id];arr.push({id,type,title:cols[2],year:Number(cols[5]),genres,poster:prev?.poster||'',overview:prev?.overview||'',tagline:prev?.tagline||'',rating:r.rating,votes:r.votes,runtime:Number(cols[7])||null,countryVerified:!!(prev?.countryVerified||country?.status==='ok'),englishVerified:!!(prev?.englishVerified||country?.status==='ok'),tmdbId:prev?.tmdbId||null,origin:'IMDb officiel — import',sourceDate:new Date().toISOString().slice(0,10),countries:prev?.countries||country?.countries||[],language:prev?.language||'unknown',adult:false});counts.matched++;if(idx%1000000===0)status.textContent='Fiches analysées : '+num(idx)}await dbSet('customTitles',arr);data.movie=mergeTitles(data.movie,arr.filter(x=>x.type==='movie'));data.tv=mergeTitles(data.tv,arr.filter(x=>x.type==='tv'));await dbSet('catalogV6',data);status.textContent=num(counts.matched)+' titres IMDb importés. Filtre pays obligatoire avant affichage.';render();verifyCountryBatch();notify('IMDb importé : '+num(counts.matched)+' titres (avant vérification géographique).')}catch(e){status.textContent='Erreur : '+e.message;notify('Import IMDb échoué : '+e.message)}}
function parseCSV(text){const rows=[];let row=[],cell='',quoted=false;for(let i=0;i<text.length;i++){let c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++}else quoted=!quoted}else if(c===','&&!quoted){row.push(cell);cell=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);cell='';if(row.some(x=>x.trim()))rows.push(row);row=[]}else cell+=c}row.push(cell);if(row.some(x=>x.trim()))rows.push(row);return rows}
function templateRT(){downloadText('cinespin-modele-rotten-tomatoes.csv','imdb_id,title,release_year,rt_url,audience_score,audience_ratings_count,production_countries,original_language,poster_url\n', 'text/csv');notify('Le modèle CSV est dans tes téléchargements.')}
async function importRT(){let file=$('rtFile')?.files[0];if(!file)return notify('Sélectionne un CSV Rotten Tomatoes.');try{let rows=parseCSV(await file.text()),heads=rows.shift().map(h=>h.trim().toLowerCase().replace(/[^a-z0-9]/g,'')),index=key=>heads.indexOf(key.replace(/[^a-z0-9]/g,'')),at=(r,...keys)=>{for(let k of keys){let n=index(k);if(n>=0&&r[n])return r[n].trim()}return''};let arr=[],dups=new Set(),reject=0;let existing=[...data.movie,...data.tv];for(const r of rows){let id=at(r,'imdb_id','imdbid'),title=at(r,'title'),year=Number(at(r,'release_year','releaseyear','year')),score=Number(at(r,'audience_score','audiencescore')),votes=Number(at(r,'audience_ratings_count','audienceratingscount','audience_count')),countries=splitCountries(at(r,'production_countries','productioncountries')),language=at(r,'original_language','originallanguage');if(!(score>75&&votes>10000&&year>=2011&&title)){reject++;continue}let match=existing.find(m=>m.id===id)||(existing.find(m=>normalizeName(m.title)===normalizeName(title)&&m.year===year));if(!id&&match)id=match.id;if(!/^tt\d+$/.test(id)){reject++;continue}if(dups.has(id)){reject++;continue}dups.add(id);let vCountries=countries.length?countries:(match?.countries||[]);let verified=checkCountry(vCountries)&&language==='en'||(match?.countryVerified&&match?.englishVerified);if(!verified){reject++;continue}let importedGenres=unique(at(r,'genres').split(/[,|]/).map(x=>cleanGen(x.trim())).filter(x=>PALETTE[x]));if(!match&&!importedGenres.length){reject++;continue}arr.push({...(match||{}),id,type:'movie',title,year,rating:match?.rating||0,votes:match?.votes||0,rtScore:score,rtCount:votes,rtUrl:at(r,'rt_url','rturl'),genres:match?.genres||importedGenres,countries:vCountries,countryVerified:true,englishVerified:true,language:'en',poster:toPosterPath(at(r,'poster_url','posterurl'))||match?.poster||'',overview:match?.overview||'',sourceDate:new Date().toISOString().slice(0,10),origin:'RT CSV confirmé',adult:false})}await dbSet('rtTitles',arr);data.movie=mergeTitles(data.movie,arr);await dbSet('catalogV6',data);$('rtStatus').textContent=num(arr.length)+' admissibles • '+num(reject)+' refusés (seuils/identité/pays)';notify(num(arr.length)+' titres Rotten Tomatoes validés.');render()}catch(e){notify('CSV invalide : '+e.message)}}
function saveTmdbKey(){let p=profile();if(!p)return;let old=val(p.settings.tmdbKey),next=val($('tmdbKey')?.value);p.settings.tmdbKey=next;if(old!==next)posterEnrichmentTried.clear();saveProfile();notify('Clé sauvegardée localement.');enrichMissingPosters();} 
async function getReviews(id){let m=data.movie.concat(data.tv).find(x=>id===idFor(x));if(!m)return;let key=val(profile()?.settings.tmdbKey),el=$('reviewArea');if(!key){notify('Ajoute une clé TMDB dans Réglages pour lire les vrais avis.');if(el)el.textContent='Aucune clé TMDB configurée : avis non consultés.';return}if(!m.tmdbId){notify('Identifiant TMDB introuvable pour ce titre.');if(el)el.textContent='Cette fiche ne possède pas d’identifiant TMDB confirmé.';return}if(m.type==='tv'){notify('Cette série n’a pas de lien TMDB vérifié pour les avis.');return}if(el)el.textContent='Lecture des avis réels…';try{let url=`https://api.themoviedb.org/3/movie/${encodeURIComponent(m.tmdbId)}/reviews?api_key=${encodeURIComponent(key)}&language=en-US&page=1`;let r=await fetchWithTimeout(url,12000);if(!r.ok)throw Error('TMDB '+r.status);let json=await r.json();let positives=(json.results||[]).filter(x=>Number(x.author_details?.rating)>=7&&x.content?.length>30);if(!positives.length){if(el)el.textContent='Pas assez d’avis positifs exploitables pour une synthèse vérifiable.';return}let keys={jeu:['acting','performance','actor','cast'],histoire:['story','script','writing','plot'],émotions:['emotional','moving','heart','touching'],humour:['funny','humor','laugh','comedy'],images:['visual','cinematography','shot','beautiful'],musique:['score','music','soundtrack'],rythme:['pacing','pace','tension','suspense'],personnages:['character','relationship','chemistry'],originalité:['original','creative','unique','fresh']};let tally=Object.entries(keys).map(([name,words])=>({name,count:positives.filter(x=>words.some(w=>new RegExp('\\b'+w+'\\b','i').test(x.content))).length})).filter(x=>x.count>=2).sort((a,b)=>b.count-a.count).slice(0,3);if(el)el.textContent=tally.length?`${positives.length} avis positifs analysés. Thèmes les plus cités : ${tally.map(x=>x.name+' ('+x.count+')').join(', ')}. Source : avis utilisateurs TMDB, page 1.`:`${positives.length} avis positifs consultés, mais aucun thème ne revient assez souvent pour établir une tendance.`}catch(e){if(el)el.textContent='Avis indisponibles : '+e.message}}
/* Event and routing */
document.addEventListener('click',async e=>{const b=e.target.closest('[data-route], [data-act]');if(!b)return;if(b.dataset.route){setRoute(b.dataset.route);return}let action=b.dataset.act,id=b.dataset.id;switch(action){case 'checkUsername':checkUsername();break;case 'takeProfile':takeProfile(b.dataset.name);break;case 'chooseOther':showOnboard();break;case 'changeProfile':changeProfile();break;case 'setAvatar':setAvatar(id);break;case 'closeModal':modalLocked=false;closeModal();break;case 'spinGenre':spinGenre();break;case 'prizeConfirm':modalLocked=false;closeModal();confirmGenre();break;case 'prizeReroll':modalLocked=false;closeModal();spinGenre();break;case 'confirmGenre':confirmGenre();break;case 'spinTitle':spinTitle();break;case 'reroll':spinTitle();break;case 'startOver':startOver();break;case 'yesStartOver':modalLocked=false;closeModal();resetSession();break;case 'chosen':chosen();break;case 'chosenWatched':{let m=currentMovie();modalLocked=false;closeModal();if(m)markSeen(idFor(m),true);break}case 'watchedCurrent':{let m=currentMovie();if(m)markSeen(idFor(m),true);break}case 'favoriteCurrent':{let m=currentMovie();if(m)toggleFavorite(idFor(m));break}case 'hideCurrent':{let m=currentMovie();if(m){toggleHidden(idFor(m));session().candidate=null;saveProfile();render()}break}case 'toggleSeen':markSeen(id);if(!$('modal').classList.contains('hidden')){modalLocked=false;closeModal()}break;case 'toggleFav':toggleFavorite(id);break;case 'toggleHidden':toggleHidden(id);break;case 'showFilm':detailModal(id);break;case 'getReviews':getReviews(id);break;case 'filterView':viewFilter=b.dataset.filter;page=0;renderCatalog(false);break;case 'prevPage':page=Math.max(0,page-1);renderCatalog(route==='seen');$('content-area').scrollIntoView({behavior:'smooth'});break;case 'nextPage':page++;renderCatalog(route==='seen');$('content-area').scrollIntoView({behavior:'smooth'});break;case 'refresh':loadData(true);break;case 'recheck':{localCountries={};try{localStorage.removeItem(COUNTRY_KEY)}catch(e){}for(const m of data.movie.concat(data.tv))if(m.origin?.includes('IMDb')&&!m.tmdbId){m.countryVerified=false;m.englishVerified=false}verifyCountryBatch();notify('Vérification des pays relancée.');break}case 'exportProgress':exportProgress();break;case 'importProgress':importProgress();break;case 'importIMDb':importIMDb();break;case 'templateRT':templateRT();break;case 'importRT':importRT();break;case 'saveTmdbKey':saveTmdbKey();break;default:console.warn('Action inconnue',action)}});
// CinéSpin V8.7 — mosaïque virtuelle cyclique. On réutilise les mêmes films
// au-delà du mur d'origine sans multiplier les milliers de <img> en mémoire.
const heroVisibilityToggle=$('heroVisibilityToggle');
const heroFrame=$('hero').querySelector('.hero-frame');
const heroCopy=$('heroCopy');
const heroGallery=$('heroPosters');
const heroHint=document.querySelector('.hero-poster-hint');
let galleryPanX=0,galleryPanY=0,galleryDrag=null,suppressGalleryClickUntil=0;
let galleryLayout=null,gallerySignature='',galleryFrameId=0,galleryRefreshTimer=0;
const galleryNodes=new Map();
const invalidPosterIds=new Set();
function galleryPosterId(m){return (m.type||'movie')+':'+m.id;}
// Avec une clé TMDB configurée, compléter les affiches absentes à partir de l'ID IMDb.
// Jamais de visuel inventé ou provenant d'une autre fiche de film.
let posterEnrichmentRunning=false;
const posterEnrichmentTried=new Set();
async function enrichMissingPosters(){
  const key=val(profile()?.settings?.tmdbKey);
  if(!key||posterEnrichmentRunning)return;
  const queue=data.movie.concat(data.tv).filter(m=>/^tt\d+$/.test(m.id||'')&&
    (!m.poster||invalidPosterIds.has(galleryPosterId(m)))&&!posterEnrichmentTried.has(galleryPosterId(m)));
  if(!queue.length)return;
  posterEnrichmentRunning=true;
  let updated=0;
  try{
    // Traitement progressif pour éviter un blocage de l'interface et les limites d'API.
    for(let i=0;i<queue.length;i+=3){
      const batch=queue.slice(i,i+3);
      const results=await Promise.allSettled(batch.map(async m=>{
        posterEnrichmentTried.add(galleryPosterId(m));
        const url='https://api.themoviedb.org/3/find/'+encodeURIComponent(m.id)+
          '?api_key='+encodeURIComponent(key)+'&external_source=imdb_id';
        const response=await fetchWithTimeout(url,12000);
        if(!response.ok)throw Error('TMDB '+response.status);
        const payload=await response.json();
        const match=(m.type==='tv'?payload.tv_results:payload.movie_results)||[];
        const found=match.find(x=>x.poster_path)||null;
        if(!found)return false;
        const poster=toPosterPath(found.poster_path);
        if(!poster)return false;
        m.poster=poster;
        if(found.id&&!m.tmdbId)m.tmdbId=Number(found.id);
        invalidPosterIds.delete(galleryPosterId(m));
        updated++;
        return true;
      }));
      if(results.some(x=>x.status==='rejected'&&/TMDB 401/.test(String(x.reason))))break;
      if(i%15===0)await sleep(100);
    }
  }finally{
    posterEnrichmentRunning=false;
    if(updated){await dbSet('catalogV6',data);gallerySignature='';updateTop();}
  }
}

function galleryModulo(n,max){return (n%max+max)%max;}
function galleryDimensions(){
  // Aligné sur les dimensions de la V8.6 : changer d'état ne change pas le zoom.
  const w=innerWidth;
  if(w<=400)return {gap:4,size:(w*1.30-5*4)/6};
  if(w<=720)return {gap:5,size:(w*1.22-5*5)/6};
  if(w<=990)return {gap:6,size:(w*1.26-8*6)/9};
  if(w>=1600)return {gap:9,size:(w*1.08-13*9)/14};
  const gap=Math.max(4,Math.min(8,w*.0048));
  return {gap,size:(w*1.14-11*gap)/12};
}
function galleryTile(m,worldRow,worldCol,dims){
  const tile=document.createElement('button');
  tile.type='button';tile.className='poster-tile';
  tile.dataset.act='showFilm';tile.dataset.id=idFor(m);
  const score=m.votes>0?'★ '+Number(m.rating).toFixed(1):m.rtScore?'🍅 '+Number(m.rtScore)+' %':'';
  tile.setAttribute('aria-label','Voir '+m.title+', '+m.year+(score?', '+score:''));
  tile.style.left=((worldCol-(galleryLayout.cols-1)/2)*dims.stepX)+'px';
  tile.style.top=((worldRow-(galleryLayout.rows-1)/2)*dims.stepY)+'px';
  tile.style.width=dims.size+'px';
  const img=document.createElement('img');
  img.src=m.poster;img.alt='';img.draggable=false;
  img.loading='lazy';img.decoding='async';
  img.addEventListener('error',()=>{
    if(img.dataset.triedOriginal!=='true'&&img.src.includes('image.tmdb.org/t/p/w500/')){
      img.dataset.triedOriginal='true';
      img.src=img.src.replace('/t/p/w500/','/t/p/original/');
      return;
    }
    // On n'attribue jamais l'affiche d'un autre film à cette fiche.
    // Sans affiche réelle, cette fiche sort simplement du mur jusqu'à une nouvelle source.
    const key=galleryPosterId(m);
    if(!invalidPosterIds.has(key)){
      invalidPosterIds.add(key);
      clearTimeout(galleryRefreshTimer);
      galleryRefreshTimer=setTimeout(()=>refreshHeroGallery(getModeArray().filter(x=>eligible(x,true)),true),240);
    }
  });
  const tip=document.createElement('span');tip.className='poster-info';
  tip.innerHTML='<strong>'+esc(m.title)+'</strong><small>'+esc(m.year+(score?' · '+score:''))+'</small>';
  tile.append(img,tip);
  return tile;
}
function refreshHeroGallery(c,force=false){
  const posters=c.filter(m=>!isHidden(m)&&!!m.poster&&!invalidPosterIds.has(galleryPosterId(m)))
    .sort((a,b)=>(b.votes||b.rtCount||0)-(a.votes||a.rtCount||0)||
      (b.rating||b.rtScore/10||0)-(a.rating||a.rtScore/10||0)||String(a.id).localeCompare(String(b.id)));
  const baseCols=innerWidth<=720?6:innerWidth<=990?9:innerWidth>=1600?14:12;
  const cols=Math.max(baseCols,Math.ceil(Math.sqrt(Math.max(1,posters.length)*1.48)));
  const rows=Math.max(1,Math.ceil(posters.length/cols));
  const signature=mode+'|'+innerWidth+'|'+cols+'|'+posters.map(m=>m.id+'@'+m.poster).join('|');
  if(!force&&gallerySignature===signature){scheduleHeroGallery();return;}
  gallerySignature=signature;
  if(!heroGallery.dataset.galleryReady){heroGallery.replaceChildren();heroGallery.dataset.galleryReady='1'}
  // Emplacement central = meilleurs films. Aux limites, les favoris du centre
  // remplissent les dernières cases avant la répétition du mur en 2D.
  const positions=Array.from({length:rows*cols},(_,i)=>{
    let x=i%cols-(cols-1)/2,y=Math.floor(i/cols)-(rows-1)/2;
    return {i,d:x*x+y*y*2.25};
  }).sort((a,b)=>a.d-b.d||a.i-b.i);
  const board=Array(rows*cols).fill(null);
  if(posters.length){
    positions.forEach((p,rank)=>{board[p.i]=posters[rank%posters.length]});
  }
  galleryLayout={cols,rows,board,postersCount:posters.length,catalogCount:c.length};
  heroGallery.setAttribute('aria-label',num(posters.length)+' affiches de cinéma à explorer. Glisse dans toutes les directions pour un défilement continu.');
  galleryNodes.forEach(node=>node.remove());galleryNodes.clear();
  // Même cadre au changement de genre/profil. L'œil se charge du retour au centre.
  if(!heroFrame.classList.contains('is-content-hidden'))resetHeroPan();
  scheduleHeroGallery();
}
function scheduleHeroGallery(){
  if(galleryFrameId)return;
  galleryFrameId=requestAnimationFrame(()=>{galleryFrameId=0;renderHeroGalleryWindow()});
}
function renderHeroGalleryWindow(){
  if(!galleryLayout?.postersCount){galleryNodes.forEach(el=>el.remove());galleryNodes.clear();return;}
  const dims=galleryDimensions();dims.stepX=dims.size+dims.gap;dims.stepY=dims.size*1.5+dims.gap;
  const a=5*Math.PI/180,co=Math.cos(a),si=Math.sin(a);
  // Coordonnées du milieu de la fenêtre, ramenées au plan incliné.
  const cx=-galleryPanX*co+galleryPanY*si;
  const cy=-galleryPanX*si-galleryPanY*co;
  const centerCol=(galleryLayout.cols-1)/2+cx/dims.stepX;
  const centerRow=(galleryLayout.rows-1)/2+cy/dims.stepY;
  const halfW=(heroFrame.clientWidth*co+heroFrame.clientHeight*si)/2;
  const halfH=(heroFrame.clientHeight*co+heroFrame.clientWidth*si)/2;
  const rangeX=Math.ceil(halfW/dims.stepX)+2,rangeY=Math.ceil(halfH/dims.stepY)+2;
  const loC=Math.floor(centerCol)-rangeX,hiC=Math.ceil(centerCol)+rangeX;
  const loR=Math.floor(centerRow)-rangeY,hiR=Math.ceil(centerRow)+rangeY;
  const visible=new Set();const fragment=document.createDocumentFragment();
  for(let row=loR;row<=hiR;row++)for(let col=loC;col<=hiC;col++){
    const key=row+':'+col;visible.add(key);
    if(galleryNodes.has(key))continue;
    const film=galleryLayout.board[galleryModulo(row,galleryLayout.rows)*galleryLayout.cols+galleryModulo(col,galleryLayout.cols)];
    if(!film)continue;
    const tile=galleryTile(film,row,col,dims);galleryNodes.set(key,tile);fragment.append(tile);
  }
  heroGallery.append(fragment);
  for(const [key,node] of galleryNodes){if(!visible.has(key)){node.remove();galleryNodes.delete(key)}}
}
function setHeroPan(x,y){
  // L'espace est périodique, aucune limite artificielle. On recentre les coordonnées
  // de temps en temps pour éviter une perte de précision après de longs glissements.
  galleryPanX=x;galleryPanY=y;
  if(galleryLayout?.postersCount){
    const dims=galleryDimensions();
    const periodX=galleryLayout.cols*(dims.size+dims.gap),periodY=galleryLayout.rows*(dims.size*1.5+dims.gap);
    // Période sur le plan de l'image, puis rotation -5° dans les coordonnées écran.
    const theta=-5*Math.PI/180,co=Math.cos(theta),si=Math.sin(theta);
    const periodScreenX=co*periodX,periodScreenY=si*periodX;
    const periodScreenBX=-si*periodY,periodScreenBY=co*periodY;
    // Repli uniquement au-delà de 4 répétitions, invisible grâce à la périodicité.
    if(Math.abs(galleryPanX)>periodX*5||Math.abs(galleryPanY)>periodY*5){
      let ix=Math.trunc((galleryPanX*co+galleryPanY*si)/periodX);
      let iy=Math.trunc((-galleryPanX*si+galleryPanY*co)/periodY);
      galleryPanX-=ix*periodScreenX+iy*periodScreenBX;
      galleryPanY-=ix*periodScreenY+iy*periodScreenBY;
      if(galleryDrag){galleryDrag.panX=galleryPanX;galleryDrag.panY=galleryPanY;galleryDrag.x=galleryDrag.lastX;galleryDrag.y=galleryDrag.lastY;}
    }
  }
  heroGallery.style.setProperty('--pan-x',galleryPanX+'px');
  heroGallery.style.setProperty('--pan-y',galleryPanY+'px');
  scheduleHeroGallery();
}
function resetHeroPan(){setHeroPan(0,0)}
heroVisibilityToggle.addEventListener('click',()=>{
  const hidden=heroFrame.classList.toggle('is-content-hidden');
  heroVisibilityToggle.setAttribute('aria-pressed',String(hidden));
  heroVisibilityToggle.setAttribute('aria-label',hidden?'Afficher le contenu du héros':'Masquer le contenu pour explorer les affiches');
  heroVisibilityToggle.title=hidden?'Réafficher le texte et les boutons':'Explorer toutes les affiches';
  heroCopy.inert=hidden;heroCopy.setAttribute('aria-hidden',String(hidden));
  heroHint.textContent=hidden?'GLISSE À L’INFINI · TOUCHE UNE AFFICHE POUR L’OUVRIR':'SURVOLE UNE AFFICHE POUR EN SAVOIR PLUS ↗';
  if(!hidden)resetHeroPan();
  heroVisibilityToggle.focus({preventScroll:true});
});
heroFrame.addEventListener('pointerdown',e=>{
  if(!heroFrame.classList.contains('is-content-hidden')||e.target.closest('.hero-visibility-toggle'))return;
  if(e.pointerType==='mouse'&&e.button!==0)return;
  galleryDrag={id:e.pointerId,x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,panX:galleryPanX,panY:galleryPanY,moved:false};
});
heroFrame.addEventListener('pointermove',e=>{
  if(!galleryDrag||galleryDrag.id!==e.pointerId)return;
  const dx=e.clientX-galleryDrag.x,dy=e.clientY-galleryDrag.y;
  if(!galleryDrag.moved&&Math.hypot(dx,dy)>7){
    galleryDrag.moved=true;heroFrame.classList.add('is-dragging');
    try{heroFrame.setPointerCapture(e.pointerId)}catch(err){}
  }
  if(galleryDrag.moved){galleryDrag.lastX=e.clientX;galleryDrag.lastY=e.clientY;setHeroPan(galleryDrag.panX+dx,galleryDrag.panY+dy)}
});
function finishHeroDrag(e){
  if(!galleryDrag||galleryDrag.id!==e.pointerId)return;
  if(galleryDrag.moved)suppressGalleryClickUntil=performance.now()+420;
  galleryDrag=null;heroFrame.classList.remove('is-dragging');
  if(heroFrame.hasPointerCapture(e.pointerId))heroFrame.releasePointerCapture(e.pointerId);
}
heroFrame.addEventListener('pointerup',finishHeroDrag);
heroFrame.addEventListener('pointercancel',finishHeroDrag);
heroFrame.addEventListener('lostpointercapture',e=>{if(e.target!==heroFrame)return;galleryDrag=null;heroFrame.classList.remove('is-dragging')});
heroFrame.addEventListener('click',e=>{
  if(e.target.closest('.hero-visibility-toggle'))return;
  if(performance.now()<suppressGalleryClickUntil){e.stopImmediatePropagation();e.preventDefault();}
},true);
let galleryResizeTimer;
window.addEventListener('resize',()=>{
  clearTimeout(galleryResizeTimer);
  galleryResizeTimer=setTimeout(()=>{
    gallerySignature='';updateTop();scheduleHeroGallery();
  },180);
},{passive:true});
$('modeMovie').addEventListener('click',()=>setMode('movie'));
$('modeTV').addEventListener('click',()=>setMode('tv'));
$('brandHome').addEventListener('click',()=>setRoute('play'));
$('heroPlay').addEventListener('click',()=>setRoute('play'));
$('heroCatalog').addEventListener('click',()=>setRoute('catalog'));
$('profileButton').addEventListener('click',changeProfile);
$('avatarButton').addEventListener('click',showAvatarPicker);
function closeDrawer(){ $('navOverlay').classList.remove('open');$('navOverlay').setAttribute('aria-hidden','true');$('burgerBtn').setAttribute('aria-expanded','false');document.body.classList.remove('menu-open')}
function openDrawer(){ $('navOverlay').classList.add('open');$('navOverlay').setAttribute('aria-hidden','false');$('burgerBtn').setAttribute('aria-expanded','true');document.body.classList.add('menu-open')}
$('burgerBtn').addEventListener('click',()=>{if($('navOverlay').classList.contains('open'))closeDrawer();else openDrawer()});$('navClose').addEventListener('click',closeDrawer);$('navOverlay').addEventListener('click',e=>{if(e.target===$('navOverlay'))closeDrawer()});
$('refreshData').addEventListener('click',()=>loadData(true));
$('closeModal').addEventListener('click',closeModal);
$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();closeDrawer()}if(e.key==='Enter'&&$('username')&&document.activeElement===$('username'))checkUsername()});
window.addEventListener('scroll',()=>{let y=window.scrollY;if(y>190&&y>scrollLast+8){$('topbar').classList.add('hidebar')}else if(y<scrollLast-7||y<65){$('topbar').classList.remove('hidebar')}scrollLast=y},{passive:true});
if('serviceWorker'in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(e=>console.warn('SW',e.message)))}
// The game is deliberately not a username-only remote authentication service.
(async()=>{if(!profile())showOnboard();const cached=await dbGet('catalogV6');if(cached?.movie?.length){data=cached;source.loading=false;source.movie=cached._source||'Données locales';source.tv='IMDb archivé';updateTop();render();verifyCountryBatch();}else loadData();})();
